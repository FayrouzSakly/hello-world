
#include <iostream>
#include <fstream> 
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "Set.h"


/** explores a whole tree defined by :
 * an operator (add edge, delete edge, split edge...)
 * the arguments (two nodes, two nodes and one timescale...) 
 **/
//, std::vector<float> best
std::pair<std::pair<Set::operation,std::string>, double> Set::branch_and_bound(std::map<std::string, int> &map_scores,
            Set::operation op, std::string &best_configuration, std::vector<float> bests) {

    // std::ofstream logs;
    // std::string title = "./branch-and-bound.log";
    // logs.open(title, std::ios::out); // open file
    
    int nb_models = op.first.second.size();

    this->logs << this->idBnB << "Branch and bound : " << nb_models << " models" << std::endl;
    std::cout << "Branch and bound : " << nb_models << " models" << std::endl;

    int potential_operator = op.first.first;
    std::pair<std::pair<std::string,std::string>, pmTgemTS> arguments = op.second;

    this->log_operation(potential_operator, arguments);

    std::string current_node(nb_models, this->default_value); // starting from root node
    std::string next_node;
    std::string defined_models, not_defined_models;

    // std::pair<int,std::string> best_score(4, current_node);
    std::pair<std::pair<Set::operation,std::string>, double> best_score;
    best_score.first.first = op;
    best_score.first.second = current_node;
    best_score.second = this->compute_score(); // compute score here ?

    bool finished = false; // is all tree explored 
    bool cut_branch = false;

    double level;
    double upperbound; // upperbound for nodes (not completely defined set)
    double score; // score for leaves (completely defined set)
    int nb_not_defined_models;
    double last_non_applied; // when looking for index of last model on which operator wasn't apply

    /* Performance indicator */
    int qtty_models_existing = 0, qtty_models_explored = 0;
    for (int i = nb_models; i >= 0; i--){
        qtty_models_existing += pow(2,i);
    }

    while (!finished) {

        // std::cout << current_node;
        this->logs << current_node << " - ";
        qtty_models_explored ++;

        level = current_node.find(this->default_value);
        cut_branch = false;

        if (level!=std::string::npos) { // if it's a node
            // std::cout << " - node level " << level << std::endl;
            // this->logs << " - node at level " << level << std::endl;

            // upperbound = map_scores[current_node];  // version hardcodée
            upperbound = this->compute_score(op, current_node, level, bests, TEST_NEIGHBOUR);
            std::cout << "Upperbound = " << upperbound << ", " << best_score.second << std::endl;
            this->logs << "Upperbound = " << upperbound << std::endl;

            if (upperbound < best_score.second) {
                cut_branch = true;
                std::cout << "Cutting branch" << std::endl;
                this->logs << "Cutting branch" << std::endl;
            }

            if (cut_branch) {
                defined_models = current_node.substr(0, level); // all models between 0 and level are defined

                if (defined_models[defined_models.size()-1] == '0') { // if last char before the 2 is a 0
                    next_node = current_node.substr(0, level-1) 
                                + '1' 
                                + current_node.substr(level);
                } else {
                    last_non_applied = level-1;
                    while ((current_node[last_non_applied] == '1') && (last_non_applied > -1)) {
                        last_non_applied--;
                    }
                    
                    if (last_non_applied == -1) {
                        finished = true;
                    }

                    if (!finished) {
                        nb_not_defined_models = current_node.size()-1-last_non_applied;
                        not_defined_models = std::string(nb_not_defined_models, this->default_value);

                        next_node = current_node.substr(0, last_non_applied) 
                                    + '1' 
                                    + not_defined_models;
                    }
                }

            } else { // if there is no need to cut a branch
                next_node = current_node.substr(0, level) 
                            + '0' 
                            + current_node.substr(level+1);
            }

        } else { // if it's a leaf (all models are defined)
            level = this->nb_tasks;

            // std::cout << " - leaf" << std::endl;
            // this->logs << " - leaf" << std::endl;

            if (current_node[current_node.size()-1] == '0') { // if last model doesn't apply operator
                next_node = current_node.substr(0, current_node.size()-1) + '1';
            } else {
                last_non_applied = current_node.size()-1; // index of last model on which operator wasn't apply

                while (current_node[last_non_applied] == '1') {
                    last_non_applied--;
                }

                if (last_non_applied == -1) { // means leaf only has '1' (all models have applied operator)
                    finished = true; // so every combination have been tried
                }

                nb_not_defined_models = current_node.size()-1-last_non_applied; // nb of 2 to add
                not_defined_models = std::string(nb_not_defined_models, '2');
                next_node = current_node.substr(0, last_non_applied) + '1' + not_defined_models;
            }

            /* score computation */
            // score = map_scores[current_node]; // version hardcodée
            score = this->compute_score(op, current_node, level, bests, TEST_NEIGHBOUR);
            std::cout << "Score (" << current_node << "): " << score << std::endl;
            this->logs << "Score = " << score << std::endl;

            if (best_score.second < score){
                this->logs << "New best score ! " << best_score.first.second << " with " << best_score.second << " replaced by ";
                // std::cout << "New best score ! " << best_score.first.second << " with " << best_score.second << " replaced by ";

                /* score actualization */
                best_score.first.second = current_node;
                // best_score.second = map_scores[current_node]; // hardcodée
                best_score.second = score;
                best_configuration = current_node;

                this->logs << best_score.first.second << " with " << best_score.second << std::endl;
                // std::cout << best_score.first.second << " with " << best_score.second << std::endl;
            }
        }

        // std::cout << std::endl;
        this->logs << std::endl;

        current_node = next_node;
    }

    std::cout << "Final score : " << best_score.first.second << " with " << best_score.second << std::endl;
    this->logs << "Final score : " << best_score.first.second << " with " << best_score.second << std::endl;

    std::string best_src = op.second.first.first;
    std::string best_dest = op.second.first.second;
    int name_choosen_operator = op.first.first;

    int rate = ((double)qtty_models_explored/(double)qtty_models_existing)*100; // change type to int for more precise score
    // std::cout << qtty_models_explored << " explored models of " << qtty_models_existing << " possible models : " << rate << "%" << std::endl;
    this->logs << qtty_models_explored << " explored models of " << qtty_models_existing << " possible models : " << rate  << "%" << std::endl << std::endl;
    this->logs_csv << this->idIteration << ";" << this->idBnB << ";"
                     << name_operator(name_choosen_operator) << ";" 
                     << best_src << ";" 
                     << best_dest << ";" 
                     << (double)qtty_models_explored << ";"
                     << (double)qtty_models_existing << ";" 
                     << best_score.first.second << ";"
                     << best_score.second << std::endl;

    // this->logs.close(); // close file to free memory

    this->idBnB++;

    return best_score;
}

double Set::compute_score(operation op, std::string configuration, int level, std::vector<float> bests, bool test){
    std::vector<int> index_models = op.first.second;
    int name_operation = op.first.first;
    std::pair<std::string,std::string> edge = op.second.first;

    std::cout << std::endl << "---- models ";
    for (int i = 0; i < index_models.size(); i ++){
        std::cout << index_models[i] << " ";
    }
    std::cout << "and configuration " << configuration << std::endl;

    double gain_score;
    int N;

    /* initialization */
    double s = 1; 
    double s_indiv = 0;

    /* prior */
    s *= this->prior;

    double score_operation;
    int index = 0;
    int id_e;

    /* posterior for each graph */

    // for (int i = 0; i < this->nb_tasks; i++){
    for (int i = 0; i < level; i++){

        // Find existing edges
        N = this->models[i].nodes.size();
        int  existing_edge[N][N] = {-1};
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) existing_edge[i][j] = -1;
        }

        int  E = this->models[i].arcs.size();
        for (int e = 0; e < E; e++) {
            int src  = this->models[i].arcs[e].src;
            int dest = this->models[i].arcs[e].dest;
            
            existing_edge[src][dest] = e;
        }

        s_indiv = 0;
        if (i == index_models[index]) { // si le modèle est concerné par l'opération
            if(configuration[index] == '1'){
                // std::cout << " (" << configuration[i]<< ")" << std::endl;

                int src_node = this->labels2id[i][edge.first];
                int dst_node = this->labels2id[i][edge.second];

                if (name_operation == OPERATOR_ADD) {
                    
                    gain_score = add_TS(this->models[i], src_node, dst_node, this->horizon, test);
                    s_indiv += gain_score;
                    // std::cout << "Gain score " << gain_score << std::endl;
                } else if (name_operation == OPERATOR_EXTEND) {
                    
                    id_e = existing_edge[src_node][dst_node];

                    gain_score = extend_TS(this->models[i], id_e, test);
                    s_indiv += gain_score;
                } else if (name_operation == OPERATOR_SPLIT) {
                    
                    id_e = existing_edge[src_node][dst_node];
                    tgem_EDGE e = this->models[i].arcs[id_e];
                    pmTgemTS ts = op.second.second;
                    int id_ts = timescale_id(e, ts);

                    gain_score = split_TS(this->models[i], id_e, id_ts, test);
                    s_indiv += gain_score;
                }
                index++;
            } else if (configuration[index] == '2') {
                s_indiv += bests[i];
            }
        }

        for (int j = 0; j < this->models[i].nodes.size(); j++) {
           s_indiv += this->models[i].nodes[j].score;
        }
        s *= s_indiv;
    }

    for (int i = level; i < this->nb_tasks; i++){
        s_indiv = 0;
        s_indiv += bests[i];
        s *= s_indiv;
    }

    return s;
}

double Set::apply_operation(operation op, std::string configuration) {
    int level = this->nb_tasks;
    std::vector<float> bests;
    bool test = CHOOSE_NEIGHBOUR;

    double score = this->compute_score(op, configuration, level, bests, test);

    return score;
}


double Set::compute_score(){

    /* initialization */
    double s = 1; 
    double s_indiv = 0;

    /* prior */
    s *= this->prior;

    /* posterior for each graph */
    for (int i = 0; i < this->nb_tasks; i++){
        s_indiv = 0;

        for (int j = 0; j < this->models[i].nodes.size(); j++) {
           s_indiv += this->models[i].nodes[j].score;
        }
        s *= s_indiv;
    }
    return s;
}

double Set::compute_prior() {
    double prior = this->z;

    double exponent = 1/(1 + (this->nb_tasks - 1) * this->delta);
    // std::cout << "exponent " << exponent << std::endl;

    for (int i = 0; i < this->nb_tasks; i++) {
        prior *= pow(this->individuals_priors[i], exponent);
    }

    int distance = 1; // temp : mettre vrai fonction de distance  

    for (int i = 0; i < this->nb_tasks; i++) {
        // std::cout << "distance = distance(model" << i << ", model" << i+1 << ")" << std::endl;
        prior *= pow(1-this->delta, distance/(this->nb_tasks - 1));
    }

    /* compute distance between k and 0 */
    // std::cout << "distance = distance(model" << this->nb_tasks << ", model" << 0 << ")" << std::endl;
    prior *= pow(1-this->delta, distance/(this->nb_tasks - 1));

    return prior;
}

// double Set::compute_prior(int level) {
//     double prior = this->z;

//     double exponent = 1/(1 + (this->nb_tasks - 1) * this->delta);
//     // std::cout << "exponent " << exponent << std::endl;

//     for (int i = 0; i < this->nb_tasks; i++) {
//         prior *= pow(this->individuals_priors[i], exponent);
//     }

//     int distance = 1; // temp : mettre vrai fonction de distance  

//     for (int i = 0; i < this->nb_tasks; i++) {
//         // std::cout << "distance = distance(model" << i << ", model" << i+1 << ")" << std::endl;
//         prior *= pow(1-this->delta, distance/(this->nb_tasks - 1));
//     }

//     /* compute distance between k and 0 */
//     // std::cout << "distance = distance(model" << this->nb_tasks << ", model" << 0 << ")" << std::endl;
//     prior *= pow(1-this->delta, distance/(this->nb_tasks - 1));

//     return prior;
// }


void Set::generate_id2labels(){
    std::map<std::string, int>::iterator it;
    std::vector<std::map<int, std::string>> id2labels;
    std::map<int, std::string> id2label;
    
    for (int i = 0; i < this->labels2id.size(); i++){
        this->id2labels.push_back(id2label);

        for (it = this->labels2id[i].begin(); it != this->labels2id[i].end(); it++){
            this->id2labels[i][it->second] = it->first;
        }
    }
}

void Set::log_operation(int potential_operator, std::pair<std::pair<std::string,std::string>, pmTgemTS> arguments) {
    std::string name_op;

    // name operator
    if (potential_operator == OPERATOR_ADD) {
        name_op = "add";
    } else if (potential_operator == OPERATOR_EXTEND){
        name_op = "extend";
    } else if (potential_operator == OPERATOR_SPLIT){
        name_op = "split";
    } else if (potential_operator == OPERATOR_REMOVE){
        name_op = "remove";
    } else if (potential_operator == OPERATOR_MERGE){
        name_op = "merge";
    } else if (potential_operator == OPERATOR_REDUCE){
        name_op = "reduce";
    }

    // std::cout << name_op;

    // arguments
    this->logs << name_op << "(" << arguments.first.first << "->" << arguments.first.second;
    if (potential_operator == OPERATOR_ADD){ // add
        this->logs << "";
    } else if (potential_operator == OPERATOR_EXTEND){ // extend
        this->logs << ", (" << arguments.second.first << "," << arguments.second.second << "]";
    } else if (potential_operator == OPERATOR_SPLIT){ // split
        this->logs << " h = " << this->get_horizon();
    } else if (potential_operator == OPERATOR_REMOVE){ // remove
        this->logs << "";
    } else if (potential_operator == OPERATOR_MERGE){ // merge
        this->logs << ", (" << arguments.second.first << "," << arguments.second.second << "] and ...";
    } else if (potential_operator == OPERATOR_REDUCE){ // reduce
        this->logs << " h = ?";
    }
    this->logs << ")" << std::endl;
}

int timescale_id(tgem_EDGE e, pmTgemTS ts){
    int id = -1;

    for (int k = 0; k < e.followers.size(); k++) {
        if ((e.tree[k].min == ts.first) and (e.tree[k].max == ts.second)) {
            id = k;
        }
    }

    return id;
}

std::string name_operator(int op){
    std::string name_op;
    if (op == OPERATOR_ADD) {
        name_op = "add";
    } else if (op == OPERATOR_EXTEND){
        name_op = "extend";
    } else if (op == OPERATOR_SPLIT){
        name_op = "split";
    } else if (op == OPERATOR_REMOVE){
        name_op = "remove";
    } else if (op == OPERATOR_MERGE){
        name_op = "merge";
    } else if (op == OPERATOR_REDUCE){
        name_op = "reduce";
    }
    return name_op;
}
