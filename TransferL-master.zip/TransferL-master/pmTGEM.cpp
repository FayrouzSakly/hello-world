
#include "pmTGEM.h"

using namespace std;
using namespace boost;
using namespace PILGRIM;

// =============================================================================
// TGEM default constructor
// =============================================================================
pmTgem::pmTgem() {}

// =============================================================================
// TGEM constructor
// vertices are added according to a list of events (without any edge)
// =============================================================================
pmTgem::pmTgem(std::vector<std::string> _events) {

    // ---------------------------
    // one node <-> one event type
    // ---------------------------
    int nb_events = size(_events);
    for (int i = 0; i < nb_events; i++) {
        this->id_2_event[i]            = _events[i];
        this->event_2_node[_events[i]] = boost::add_vertex(i, this->graph);
    }

    // --------------------------------------------
    // create the past and the parents of this node
    // --------------------------------------------
    this->past         = new pmTgemOCCList[nb_events];
    this->parents      = new pmTgemParents[nb_events];
    this->nb_TSparents = new int[nb_events] ();
    this->neighbours   = new pmTgemNeighbour[nb_events];
}

// =============================================================================
// TGEM destructor
// =============================================================================
pmTgem::~pmTgem() {

  for (pmTgemEdgeIterator i_edge = edges(this->graph).first; i_edge != edges(this->graph).second; ++i_edge) {
      //this->edge_TSlist[*i_edge]->erase(); // = NULL
  }

  //for (int i = 0 ; i < size(_events) ; i++) {
  //    this->past[i_vertex].clear();
  //    this->parents[i_vertex].clear();
  //}

  // -----------------------
  // delete what was created
  // -----------------------
  delete(this->past);
  delete(this->parents);
  delete(this->nb_TSparents);
  delete(this->neighbours);
}

// =============================================================================
// gets the index of a vertex
// =============================================================================
int pmTgem::node_2_id(pmTgemNode _node) {


  // -------------------------------
    // return the index of this node
    // -----------------------------
    return (boost::get( get(vertex_index_t(), this->graph), _node));
}

// =============================================================================
// gets a TGEM edge if existing between a source and a destination
// =============================================================================
pmTgemEdge pmTgem::get_edge(pmTgemNode    _src,
                            pmTgemNode    _dest,
                            bool*         _existing) {

    int my_source = pmTgem::node_2_id(_src);
    int my_target = pmTgem::node_2_id(_dest);

    // -----------------
    // retrieve the edge
    // -----------------
    pmTgemEdgeIterator i_edge = edges(this->graph).first;
    for (; i_edge != edges(this->graph).second; ++i_edge) {

           if (pmTgem::node_2_id(source(*i_edge, this->graph)) == my_source
            && pmTgem::node_2_id(target(*i_edge, this->graph)) == my_target) {

               (*_existing) = true;
               return(*i_edge);
           }
    }

    // ----------------------
    // edge was not retrieved
    // ----------------------
    (*_existing) = false;
    return(*i_edge);
}

// =============================================================================
// gets the TS of an edge
// =============================================================================
pmTgemTSList pmTgem::get_TSlist(pmTgemEdge _edge) {

  // ------------------------------
    // return the TSlist of this edge
    // ------------------------------
    return (boost::get( get(edge_timescales_t(), this->graph), _edge));
}

// =============================================================================
// sets the TS of an edge
// =============================================================================
void pmTgem::set_TSlist(pmTgemEdge           _edge,
                        pmTgemTSList&        _tslist) {

    // ------------------------------
    // update the TSlist of this edge
    // ------------------------------
    boost::put(get(edge_timescales_t(), this->graph),  _edge,   _tslist);
}

// =============================================================================
// gets the horizon of a TGEM edge
// =============================================================================
double pmTgem::get_horizon(pmTgemEdge _edge) {

    // ----------------------------
    // get the edge and its TS list
    // ----------------------------
    double         horizon  = 0.0;
    pmTgemTSList   tslist   = pmTgem::get_TSlist (_edge);

    // -----------------------------------------------
    // horizon is the upper TS boundary of the TS list
    // -----------------------------------------------
    for (std::list<pmTgemTS>::iterator i_ts = tslist.begin(); i_ts != tslist.end(); ++i_ts) {
         double             val = (*i_ts).second;
         if (val > horizon) horizon = val;
    }
    return(horizon);
}

// =============================================================================
// displays the graph of a TGEM
// =============================================================================
void pmTgem::display_neighbours(void) {

    std::cout << " ---------------------------- " << std::endl;
    std::cout << " TGEM neighbour graphs are  : " << std::endl;
    std::cout << " ---------------------------- " << std::endl;

    // ----------------------------------
    // PRINT ALL THE REACHABLE NEIGHBOURS
    // ----------------------------------
    int nb_neighbours = 0;
    this->neighbour_mode = 1;
    //if (choice == TGEM_OPERATOR_ADD) {
    //   double hrz = 8; // distinct horizon values are infinite
    //   if (! tgem_1.add_edge(src, trg, hrz)) std::cout << "this edge was not added !!" << std::endl;
    //}

    for (pmTgemEdgeIterator i_edge = edges(this->graph).first; i_edge != edges(this->graph).second; ++i_edge) {
        for (int i_operator = TGEM_OPERATOR_EXTEND; i_operator <= TGEM_OPERATOR_SPLIT; ++i_operator) {

            pmTgemTSList   tslist   = pmTgem::get_TSlist (*i_edge);

            int ret = 0;
            // --------------
            // split operator
            // --------------
            if (i_operator == TGEM_OPERATOR_SPLIT) {

              for (int i_ts = 0; i_ts < tslist.size(); i_ts++) {

                  pmTgemEdge edge = *i_edge;
                  ret = pmTgem::apply_operator_edge(edge, i_operator, i_ts);
                  if (ret > 0) {
                     nb_neighbours ++;
                     /*pmTgemNeighbour
                     std::tuple<int, pmTgemNode, int> this_neighbour = std::make_tuple(i_operator, edge, i_ts);
                     int        op;
                     pmTgemNode node;
                     int        val;
                     std::tie(op, node, val) = this_neighbour;
                     */
                     //std::cout << "split neighbour = <" << i_operator << "," << (pmTgem::node_2_id(edge)) << "," << i_ts << ">" << std::endl;
                  }
              }
            }

            // ---------------
            // other operators
            // ---------------
            else {

                 pmTgemEdge edge = *i_edge;
                 ret = pmTgem::apply_operator_edge(edge, i_operator);
                 if (ret > 0) {
                   nb_neighbours ++;
                   /*pmTgemNeighbour
                   std::tuple<int, pmTgemNode, int> this_neighbour = std::make_tuple(i_operator, edge, -1);
                   int        op;
                   pmTgemNode node;
                   int        val;
                   std::tie(op, node, val) = this_neighbour;
                   */
                   //std::cout << "extend neighbour = <" << i_operator << "," << (pmTgem::node_2_id(edge)) << "," << (-1) << ">" << std::endl;
                 }
            }
          }
      }
      std::cout << "nb neighbours = " << nb_neighbours << std::endl;
      this->neighbour_mode = 0;
}

// =============================================================================
// displays the graph of a TGEM
// =============================================================================
void pmTgem::display_graph(std::vector<std::string> _events) {

    std::cout << " ------------- " << std::endl;
    std::cout << " TGEM graph  : " << std::endl;
    std::cout << " ------------- " << std::endl;

    // -------------------
    // PRINT ALL THE EDGES
    // -------------------
    for (pmTgemEdgeIterator i_edge = edges(this->graph).first; i_edge != edges(this->graph).second; ++i_edge) {

      int           id_source    = pmTgem::node_2_id (source(*i_edge, this->graph));
      int           id_target    = pmTgem::node_2_id (target(*i_edge, this->graph));
      pmTgemTSList  graph_tslist = pmTgem::get_TSlist (*i_edge);

      std::cout << "        (" << _events[id_source] << "->" << _events[id_target] << ") with TS ";
		  for (std::list<pmTgemTS>::iterator i_ts = graph_tslist.begin(); i_ts != graph_tslist.end(); ++i_ts) {
			       std::cout << " (" << (*i_ts).first << "," << (*i_ts).second << "] ";
		  }
		  std::cout << std::endl;

    }
    std::cout << std::endl;
}

// =============================================================================
// adds an edge into a TGEM
// =============================================================================
int pmTgem::add_edge(std::string    _src,
                     std::string    _dest,
                     double         _horizon) {

    pmTgemNode node_src  = this->event_2_node[_src];
    pmTgemNode node_dest = this->event_2_node[_dest];
    int        id_src    = pmTgem::node_2_id(node_src);
    int        id_dest   = pmTgem::node_2_id(node_dest);

    // ----------------------------
    // get the edge and its TS list
    // ----------------------------
    bool       existing = false;
    pmTgemEdge edge     = pmTgem::get_edge (node_src, node_dest, &existing);
    if (existing) return(0);

    // -----------------------
    // create TS (0, _horizon]
    // -----------------------
    pmTgemTSList new_TSlist;
    new_TSlist.push_front(std::make_pair(0,_horizon));

    // ------------------------------------------
    // update the configuration of each occurence
    // due to this additional parent
    // ------------------------------------------
    for (std::list<pmTgemOCC>::iterator it=this->past[id_dest].begin(); it!=this->past[id_dest].end() ; ++it) {
        pmTgemOCC       this_occ = *it;
        double          now      = this_occ.first;
        int             config   = this_occ.second;
        if (neighbour_mode == 0) {
          if (config < 0) *it      = std::make_pair(now, pmTgem::scan_past(_src, now-_horizon, now));
          else            *it      = std::make_pair(now, config * 2 + pmTgem::scan_past(_src, now-_horizon, now));
        }
    }
    if (neighbour_mode > 0) return(1);
    pmTgem::display_past(_dest);

    // -----------------------------------------------------------
    // source node is an additional parent of the destination node
    // -----------------------------------------------------------
    this->parents[id_dest].push_back(id_src);
    (this->nb_TSparents[id_dest])++;

    // --------------------------------------------------------
    //                       TS
    // insert     edge src ------> dest     into the TGEM graph
    // --------------------------------------------------------
    pmTgem::set_TSlist(boost::add_edge(node_src, node_dest, this->graph).first, new_TSlist);

    return(1);
}

// =============================================================================
// extends the timescales list of a TGEM edge
// =============================================================================
int pmTgem::extend_edge(pmTgemEdge _edge) {

    // ----------------------------
    // check and update the TSlist
    // ----------------------------
    pmTgemTSList  tslist  = pmTgem::get_TSlist(_edge);
    double        horizon = pmTgem::get_horizon(_edge);
    tslist.push_back(std::make_pair(horizon, 2*horizon));

    pmTgemNode  node_src  = source(_edge, this->graph);
    pmTgemNode  node_dest = target(_edge, this->graph);
    int         id_src    = pmTgem::node_2_id(node_src);
    int         id_dest   = pmTgem::node_2_id(node_dest);

    // ------------------------------------------
    // update the configuration of each occurence
    // due to this additional parent
    // ------------------------------------------
    int i = -1;
    std::list<int>::iterator it = this->parents[id_dest].begin();
    bool done = false;
    while ((it != this->parents[id_dest].end()) && (! done)) {
          int this_parent = *it;
          pmTgemEdge edge;
          if (this_parent == id_src) {
             done = true;
             edge = _edge;
             //std::cout << "(EXTEND -->) done TRUE for parent " << (this->id_2_event[this_parent]) << std::endl;
          }
          else {
            pmTgemNode node_parent = this->event_2_node[this->id_2_event[this_parent]];
            bool existing = false;
            edge = pmTgem::get_edge (node_parent, node_dest, &existing);
            //std::cout << "(EXTEND -->) done FALSE for parent " << (this->id_2_event[this_parent]) << " and existing " << existing << std::endl;
            if (! existing) return(0);
          }

          pmTgemTSList this_tslist = pmTgem::get_TSlist(edge);
          i += this_tslist.size();
          //std::cout << "(EXTEND -->) i = " << i << std::endl;
          ++it;
    }
    int k_factor = (int) (pow(2, this->nb_TSparents[id_dest]-i-1));
    int l_factor = (int) (pow(2, i+1));

    for (std::list<pmTgemOCC>::iterator it=this->past[id_dest].begin(); it!=this->past[id_dest].end() ; ++it) {
        pmTgemOCC       this_occ = *it;
        double          now      = this_occ.first;
        int             config   = this_occ.second;
        if (config < 0) return(0); // should not happen
        if (neighbour_mode == 0)  {*it = std::make_pair(now, (config / k_factor) * l_factor
                                                     + (config % k_factor)
                                                     + pmTgem::scan_past(_edge, now-2*horizon, now-horizon) * l_factor / 2);
                                  }
    }
    if (neighbour_mode > 0) return(1);
    pmTgem::display_past(this->id_2_event[id_dest]);

    // --------------------
    // additional TS parent
    // --------------------
    (this->nb_TSparents[id_dest])++;

    // -----------------------------
    // add this TS to the TGEM graph
    // -----------------------------
    set_TSlist(_edge, tslist);

    return(1);
}

// =============================================================================
// splits the last timescale of a TGEM edge into two timescales
// =============================================================================
int pmTgem::split_edge(pmTgemEdge _edge,
                       int        _row) {

    // ------------------------
    // get and check the TSlist
    // ------------------------
    pmTgemTSList  tslist  = pmTgem::get_TSlist(_edge);
    if (_row >= tslist.size()) {
       std::cout << "SPLIT error row is too large!";
       return(0);
    }
    //std::cout << "(SPLIT -->) row = " << _row << std::endl;
    std::list<pmTgemTS>::iterator i_ts = tslist.begin();
    int      row = 0;
    pmTgemTS ts;
    do {
           ts = (*i_ts);
           row++;
           if (row <= _row) ++i_ts;
    } while ((i_ts != tslist.end()) && (row <= _row));

    double           mid  = (ts.first + ts.second) / 2.0;
    //std::cout << "(SPLIT -->) mid = " << mid << std::endl;

    // ------------------------------------------------
    // remove the last TS of the TS list (-1 TS)
    // replace with two TS by splitting in half (+2 TS)
    // ------------------------------------------------
    i_ts = tslist.erase(i_ts);
    tslist.insert(i_ts, std::make_pair(ts.first, mid));
    tslist.insert(i_ts, std::make_pair(mid, ts.second));

    pmTgemNode  node_src  = source(_edge, this->graph);
    pmTgemNode  node_dest = target(_edge, this->graph);
    int         id_src    = pmTgem::node_2_id(node_src);
    int         id_dest   = pmTgem::node_2_id(node_dest);

    // ------------------------------------------
    // update the configuration of each occurence
    // due to this additional parent
    // ------------------------------------------
    int i = -1;
    std::list<int>::iterator it = this->parents[id_dest].begin();
    bool done = false;
    while ((it != this->parents[id_dest].end()) && (! done)) {
          int this_parent = *it;
          pmTgemEdge edge;
          if (this_parent == id_src) {
             done = true;
             edge = _edge;
             //std::cout << "(SPLIT -->) done TRUE for parent " << (this->id_2_event[this_parent]) << std::endl;
             pmTgemTSList this_tslist = pmTgem::get_TSlist(edge);
             i += (_row + 1);
          }
          else {
            pmTgemNode node_parent = this->event_2_node[this->id_2_event[this_parent]];
            bool existing = false;
            edge = pmTgem::get_edge (node_parent, node_dest, &existing);
            //std::cout << "(SPLIT -->) done FALSE for parent " << (this->id_2_event[this_parent]) << " and existing " << existing << std::endl;
            if (! existing) return(0);
            pmTgemTSList this_tslist = pmTgem::get_TSlist(edge);
            i += this_tslist.size();
          }

          //std::cout << "(SPLIT -->) i = " << i << std::endl;
          ++it;
    }
    int k_factor = (int) (pow(2, this->nb_TSparents[id_dest]-i));
    int l_factor = k_factor / 2;

    for (std::list<pmTgemOCC>::iterator it=this->past[id_dest].begin(); it!=this->past[id_dest].end() ; ++it) {
        pmTgemOCC       this_occ = *it;
        double          now      = this_occ.first;
        int             config   = this_occ.second;
        if (config < 0) return(0); // should not happen
        //std::cout << "(SPLIT -->) config was =  " << config << std::endl;
        //std::cout << "(SPLIT -->) splitted was =  " << ((2 * config / k_factor) % 2) << std::endl;
        double new_conf = (config / k_factor) * 2 * k_factor + (config % l_factor);
        if ((2 * config / k_factor) % 2 > 0) {
          new_conf += pmTgem::scan_past(_edge, now-mid, now-ts.first)  * l_factor * 2
                    + pmTgem::scan_past(_edge, now-ts.second, now-mid) * l_factor;

        }

        if (neighbour_mode == 0) *it = std::make_pair(now, new_conf);
    }

    if (neighbour_mode > 0) return(1);
    pmTgem::display_past(this->id_2_event[id_dest]);

    // -------------------------------------------------
    // one additional TS parent (-1 TS + 2 TS  = + 1 TS)
    // -------------------------------------------------
    (this->nb_TSparents[id_dest])++;

    // -----------------------------
    // add this TS to the TGEM graph
    // -----------------------------
    set_TSlist(_edge, tslist);

    return(1);
}

// =============================================================================
// removes the single timescale of a TGEM edge
// =============================================================================
int pmTgem::remove_edge(pmTgemEdge _edge) {

    // ---------------------------
    // check and update the TSlist
    // ---------------------------
    pmTgemTSList  tslist  = pmTgem::get_TSlist(_edge);
    if (tslist.size() != 1) return(0);
    tslist.pop_front();

    // ----------------------------------------------
    // remove this TS and this edge to the TGEM graph
    // ----------------------------------------------
    set_TSlist(_edge, tslist);
    pmTgemNode  node_src  = source(_edge, this->graph);
    pmTgemNode  node_dest = target(_edge, this->graph);
    boost::remove_edge(node_src, node_dest, this->graph);

    // ----------------------------
    // remove one TS parent (-1 TS)
    // ----------------------------
    int id_dest = pmTgem::node_2_id(node_dest);
    (this->nb_TSparents[id_dest])--;

    return(1);
}

// =============================================================================
// merges the two last mergeable timescales of a TGEM edge
// =============================================================================
int pmTgem::merge_edge(pmTgemEdge _edge) {

    // ----------------------------
    // check and update the TSlist
    // ----------------------------
    pmTgemTSList  tslist  = pmTgem::get_TSlist(_edge);
    if (tslist.size() < 2) return(0);
    pmTgemTS      ts2     = tslist.back();
    tslist.pop_back();
    pmTgemTS      ts1     = tslist.back();
    tslist.pop_back();
    pmTgemTSList  tslist_;
    bool          done    = false;
    bool          empty   = false;
    do {

      if (ts1.second == ts2.first && ts1.first + ts2.second == ts1.second + ts2.first) {
         tslist_.push_front(std::make_pair(ts1.first, ts2.second));
         done = true;
      }

      else if (tslist.size() >= 1) {
          pmTgemTS ts0 = tslist.back();
          tslist.pop_back();
          tslist_.push_front(std::make_pair(ts2.first, ts2.second));
          ts2.first  = ts1.first;
          ts2.second = ts1.second;
          ts1.first  = ts0.first;
          ts1.second = ts0.second;
      }

      else empty = true;

    } while (! (empty || done));

    if (done) tslist.insert(tslist.end(), tslist_.begin(), tslist_.end());

    // -----------------------------------------
    // the resulting TS list contain one TS less
    // -----------------------------------------
    set_TSlist(_edge, tslist);
    pmTgemNode  node_dest = target(_edge, this->graph);
    int         id_dest   = pmTgem::node_2_id(node_dest);
    (this->nb_TSparents[id_dest])--;

    return(1);
}

// =============================================================================
// reduces the timescales list of a TGEM edge
// =============================================================================
int pmTgem::reduce_edge(pmTgemEdge _edge) {

    // ----------------------------
    // check and update the TSlist
    // ----------------------------
    pmTgemTSList  tslist  = pmTgem::get_TSlist(_edge);
    if (tslist.size() < 2) return(0);
    pmTgemTS ts = tslist.back();
    if (ts.first*2 != ts.second) return(0);
    tslist.pop_back();

    // -----------------------------------------
    // the resulting TS list contain one TS less
    // -----------------------------------------
    set_TSlist(_edge, tslist);
    pmTgemNode  node_dest = target(_edge, this->graph);
    int         id_dest   = pmTgem::node_2_id(node_dest);
    (this->nb_TSparents[id_dest])--;

    return(1);
}

// =============================================================================
// applies an operator on an existing edge
// =============================================================================
int pmTgem::apply_operator_edge(pmTgemEdge _edge,
                                int        _operator) {

   switch (_operator) {

      case TGEM_OPERATOR_EXTEND:  return(extend_edge(_edge));
                                  break;

      case TGEM_OPERATOR_REMOVE:  return(remove_edge(_edge));
                                  break;

      case TGEM_OPERATOR_MERGE:   return(merge_edge(_edge));
                                  break;

      case TGEM_OPERATOR_REDUCE:  return(reduce_edge(_edge));
                                  break;

      default:                    return(0);
   }

   return(0);
}

// =============================================================================
// applies an operator on an existing edge
// =============================================================================
int pmTgem::apply_operator_edge(pmTgemEdge     _edge,
                                int            _operator,
                                int            _row) {

   switch (_operator) {

           case TGEM_OPERATOR_SPLIT:   return(split_edge(_edge, _row));
                                       break;

           default:                    return(0);
  }
}

// =============================================================================
// applies an operator on an existing edge
// =============================================================================
int pmTgem::apply_operator(std::string    _src,
                           std::string    _dest,
                           int            _operator) {

   // -----------------------------------------
   // apply the operator only for existing edge
   // -----------------------------------------
   pmTgemNode node_src  = this->event_2_node[_src];
   pmTgemNode node_dest = this->event_2_node[_dest];
   bool       existing  = false;
   pmTgemEdge edge      = pmTgem::get_edge (node_src, node_dest, &existing);
   if (! existing) return(0);

   return(apply_operator_edge(edge, _operator));
}
// =============================================================================
// applies an operator on an existing edge
// =============================================================================
int pmTgem::apply_operator(std::string    _src,
                           std::string    _dest,
                           int            _operator,
                           int            _row) {

   // -----------------------------------------
   // apply the operator only for existing edge
   // -----------------------------------------
   pmTgemNode node_src  = this->event_2_node[_src];
   pmTgemNode node_dest = this->event_2_node[_dest];
   bool       existing  = false;
   pmTgemEdge edge      = pmTgem::get_edge (node_src, node_dest, &existing);
   if (! existing) return(0);

   return(apply_operator_edge(edge, _operator, _row));
}
// =============================================================================
// computes the distance between 2 TGEM graphs (missing edges)
// =============================================================================
int pmTgem::distance_diff(pmTgemGraph _othergraph) {

    double dist = 0.0;

    for (pmTgemEdgeIterator i_edge = edges(_othergraph).first; i_edge != edges(_othergraph).second; ++i_edge) {

      pmTgemNode    that_source = source(*i_edge, _othergraph);
      pmTgemNode    that_target = target(*i_edge, _othergraph);

      bool                   existing  = false;
      pmTgemEdge             edge      = pmTgem::get_edge (that_source, that_target, &existing);
      if (!existing)         dist     += 1.0;
    }

    return(dist);
}

// =============================================================================
// computes the distance between 2 TGEM graphs (common edges)
// =============================================================================
double pmTgem::distance_same(pmTgemGraph _othergraph) {

    double dist = 0.0;

    for (pmTgemEdgeIterator i_edge = edges(_othergraph).first; i_edge != edges(_othergraph).second; ++i_edge) {

      pmTgemNode    that_source = source(*i_edge, _othergraph);
      pmTgemNode    that_target = target(*i_edge, _othergraph);
      pmTgemTSList  that_tslist = pmTgem::get_TSlist (*i_edge);

      bool          existing    = false;
      pmTgemEdge    edge        = pmTgem::get_edge (that_source, that_target, &existing);

      if (existing) {

         pmTgemTSList  this_tslist = pmTgem::get_TSlist (edge);

         std::list<int> pairing;

         for (std::list<pmTgemTS>::iterator i_ts = that_tslist.begin(); i_ts != that_tslist.end(); ++i_ts) {
   			       pairing.push_back((*i_ts).second);
   		   }

         for (std::list<pmTgemTS>::iterator i_ts = this_tslist.begin(); i_ts != this_tslist.end(); ++i_ts) {
   			       pairing.push_back((*i_ts).second);
   		   }

         pairing.sort();
         int    all      = pairing.size();
         pairing.unique();
         int    distinct = pairing.size();

         int nb_paired   = all - distinct;
         int nb_unpaired = all - 2 * nb_paired;
         dist           += (1.0 * nb_unpaired/(nb_paired + nb_unpaired));
      }
    }

    return(dist);
}

// =============================================================================
// forward (add_edge, extend_edge, split_edge)
// =============================================================================
int pmTgem::forward(void) {

  std::vector<int> myList;
  for (int i = TGEM_OPERATOR_ADD; i <= TGEM_OPERATOR_SPLIT; i++) {
      myList.push_back( i );
  }
  std::random_device rd;
  std::mt19937 ggg(rd());
  std::shuffle(myList.begin(), myList.end(), ggg);

  copy(myList.begin(), myList.end(), std::ostream_iterator<int>(std::cout, " "));
  std::cout << std::endl;

  bool done = false;
  int   cnt = 0;
  do {

     int choice = myList.back();
     myList.pop_back();

     std::cout << "applying operator " << choice << std::endl;

     if (edges(this->graph).first == edges(this->graph).second) {
        cnt ++;
        if (pmTgem::add_edge("A", "B", 8)) done = true;
     }
     else {

         if (choice == TGEM_OPERATOR_ADD) {
           cnt ++;
           switch (cnt) {
             case 1: if (pmTgem::add_edge("A", "B", 8)) done = true;
                     break;
             case 2: if (pmTgem::add_edge("B", "C", 8)) done = true;
                     break;
             case 3: if (pmTgem::add_edge("C", "D", 8)) done = true;
                     break;
             case 4: if (pmTgem::add_edge("A", "C", 8)) done = true;
                     break;
             case 5: if (pmTgem::add_edge("B", "D", 8)) done = true;
                    break;
             case 6: if (pmTgem::add_edge("A", "D", 8)) done = true;
                     break;
             case 7: if (pmTgem::add_edge("A", "A", 8)) done = true;
                     break;
             case 8: if (pmTgem::add_edge("B", "B", 8)) done = true;
                     break;
             case 9: if (pmTgem::add_edge("C", "C", 8)) done = true;
                     break;
             case 10: if (pmTgem::add_edge("D", "D", 8)) done = true;
                     break;
             default: break;
           }
         }
         else {
           for (pmTgemEdgeIterator i_edge = edges(this->graph).first; i_edge != edges(this->graph).second; ++i_edge) {

               pmTgemNode    chosen_source = source(*i_edge, this->graph);
               pmTgemNode    chosen_target = target(*i_edge, this->graph);
               cnt ++;
               if (pmTgem::apply_operator_edge(*i_edge, choice)) done = true;
           }
         }
     }
  } while ((done == false) && (!myList.empty()) && (cnt <= 10));

  if (cnt > 11) std::cout << "pb sur les operateurs" << std::endl;

  // Whether an operator was successfully applied or not
  return(done == true);
}

// =============================================================================
// =============================================================================
void pmTgem::display_past (std::string _event) {

  int event_row = pmTgem::node_2_id(this->event_2_node[_event]);
  std::cout << "PAST of " << _event << " is made of this : ";
  for (std::list<pmTgemOCC>::iterator it=this->past[event_row].begin(); it!=this->past[event_row].end() ; ++it) {
      pmTgemOCC this_occ = *it;
      std::cout << " (t=" << this_occ.first << ",config=" << this_occ.second << ")";
  }
  std::cout << std::endl;
}

// =============================================================================
// =============================================================================
void pmTgem::fill_past        (std::string           _event,
                               std::list<double>&    _occ) {

     int event_row = pmTgem::node_2_id(this->event_2_node[_event]);
     while (! _occ.empty()) {
         double Tocc = _occ.front();
         _occ.pop_front();
         this->past[event_row].push_back(std::make_pair(Tocc, -1));
     }
     pmTgem::display_past(_event);
     return;
}

// =============================================================================
// =============================================================================
int pmTgem::scan_past   (int           _idnode,
                         double        _begin,
                         double        _end) {

  for (std::list<pmTgemOCC>::iterator it=this->past[_idnode].begin(); it!=this->past[_idnode].end() ; ++it) {
      pmTgemOCC this_occ = *it;
      if (this_occ.first >= _begin && this_occ.first < _end) return(1);
  }

  return(0);
}

// =============================================================================
// =============================================================================
int pmTgem::scan_past   (pmTgemNode    _node,
                         double        _begin,
                         double        _end) {


  return(pmTgem::scan_past(pmTgem::node_2_id(_node), _begin, _end));
}

// =============================================================================
// =============================================================================
int pmTgem::scan_past (std::string     _event,
                       double          _begin,
                       double          _end) {

  return(pmTgem::scan_past(this->event_2_node[_event], _begin, _end));
}

// =============================================================================
// =============================================================================
int pmTgem::scan_past   (pmTgemEdge   _edge,
                         double       _begin,
                         double       _end) {

  return(pmTgem::scan_past(source(_edge, this->graph), _begin, _end));
}

// =============================================================================
// =============================================================================
void pmTgem::display_parents (std::string _event) {

  int event_row = pmTgem::node_2_id(this->event_2_node[_event]);
  std::cout << "PARENTS of " << _event << " are : ";
  for (std::list<int>::iterator it = this->parents[event_row].begin(); it != this->parents[event_row].end() ; ++it) {
      int this_parent = *it;
      std::cout << " " << (this->id_2_event[this_parent]);
  }
  std::cout << std::endl;
}

// =============================================================================
// =============================================================================
int pmTgem::getNbParents   (pmTgemNode _node)  {

  int   id = pmTgem::node_2_id(_node);
  return(this->nb_TSparents[id]);
  /*
	int nbParents = 0;
	int id_node   = pmTgem::node_2_id(_node);

	for (pmTgemEdgeIterator i_edge = edges(this->graph).first; i_edge != edges(this->graph).second; ++i_edge) {

      int           id_source    = pmTgem::node_2_id (source(*i_edge, this->graph));
     	int           id_target    = pmTgem::node_2_id (target(*i_edge, this->graph));
      pmTgemTSList  graph_tslist = pmTgem::get_TSlist (*i_edge);

		  if (id_target == id_node) nbParents += graph_tslist.size();
	}

  return (nbParents);
  */
}

// =============================================================================
// =============================================================================
int pmTgem::getNbParents   (std::string _event)  {

	return(pmTgem::getNbParents(this->event_2_node[_event]));
}

// =============================================================================
// =============================================================================
int pmTgem::getNbParents   (pmTgemEdge _edge)  {

  return(pmTgem::getNbParents(target(_edge, this->graph)));
}


// =============================================================================
// =============================================================================
int pmTgem::generate_sampling() {
//
//              TO BE DONE
// SAMPLING  => nodes having no parents generate first
//              then their children ...
//              TGEM can contain cycles thus use topological sorting
/*
  using Graph = adjacency_list < vecS, vecS, directedS >;
  //typedef adjacency_list < vecS, vecS, directedS > Graph;
  const int N = 6;
  Graph G(N);
  add_edge(0, 1, G);
  add_edge(1, 1, G);
  add_edge(1, 3, G);
  add_edge(1, 4, G);
  add_edge(3, 4, G);
  add_edge(3, 0, G);
  add_edge(4, 3, G);
  add_edge(5, 2, G);

  std::vector<int> c(N);
  int num = strong_components
    (G, make_iterator_property_map(c.begin(), get(vertex_index, G), c[0]));

  std::cout << "Total number of components: " << num << std::endl;
  std::vector < int >::iterator i;
  for (i = c.begin(); i != c.end(); ++i) {
    	std::cout << "Vertex " << i - c.begin() << " is in component " << *i << std::endl;
  }
  */
 }
