
#include <vector>

#include "Set.h"

typedef std::map< std::pair <std::pair<std::string,std::string>, pmTgemTS>, std::vector<int> > edgeConfiguration;
typedef std::pair<std::pair<int, std::vector<int> >, std::pair<std::pair<std::string,std::string>, pmTgemTS> > operation;

void display_edge_configuration(edgeConfiguration map);  
void display_list_operations(std::vector<operation> list_operations);
void display_operation(operation op);


edgeConfiguration create_edge_configuration(std::vector<std::string> events);
edgeConfiguration build_edge_configuration(std::vector<std::string> events, 
            std::vector<tgem_GRAPH> graphs, std::vector<std::map<int, std::string>> id2labels);
std::vector<operation> create_list_operations(edgeConfiguration map, bool forward);
void display_nodes_name(std::vector<std::string> events, Set s);

std::vector<float> find_best_neighbour(std::vector<tgem_GRAPH> &graphs, Set::operation oper,
                                    std::vector<std::map<std::string, int>> labels2id,
                                    std::vector<std::map<int, std::string>> id2labels);


std::vector<std::map<std::string,std::map<std::string,int>>> initialize_existing_edges(std::vector<tgem_GRAPH> graphs,
                                    std::vector<std::map<int, std::string>> id2labels);


// pmTgemTSList ts1;
// ts1.push_front(std::make_pair(0,5));
// ts1.push_front(std::make_pair(5,10));

// pmTgemTSList::iterator list_it;
// for(list_it = timescale.begin(); list_it!= timescale.end(); list_it++)
// {
//     std::cout << "(" << list_it->first << "," << list_it->second << "]" << std::endl;
// }

