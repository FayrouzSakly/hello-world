
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <limits.h>
#include <math.h>
#include <map>
#include <list>
#include <vector>
#include <pl.h>

#include <pilgrim/general/pmBayesianNetwork.h>
#include "pmTGEM.h"

// =================================================
// STRUCTURES AND TYPES
// =================================================

  #define OBSRV_EPSILON		(0.1)
  #define TIME_MAX		(99999.9)
  #define TEST_NEIGHBOUR	0
  #define CHOOSE_NEIGHBOUR	1

  typedef std::vector<double>   tgem_SEQUENCE;

  struct tgem_EFFECT {
      double 			time;
      int    			code;
      int 			size;
  };

  struct tgem_TS {
      double 			min;
      double 			max;
      int    			parent;
      int   			brotherR;
      int    			childL;
      std::vector<tgem_EFFECT>	effects;
  };

  struct tgem_EDGE {
      int 			src;
      int 			dest;
      std::vector<tgem_TS>	tree;
      std::vector<int>		followers;
      std::vector<tgem_EFFECT>	edge_effects;
  };

  struct tgem_TRIGGER {
      int 	   		nbocc;
      double 	   		duration;
  };

  struct tgem_NODE {
      std::string 		   	name;
      double			score;
      std::vector<double>  	occurs;
      std::vector<int>	 	parents_edges;
      std::vector<tgem_EFFECT>	parents_effects;
      std::vector<tgem_TRIGGER> causes;
  };

  #define OPERATOR_ADD		0
  #define OPERATOR_EXTEND	1
  #define OPERATOR_SPLIT	2

  #define OPERATOR_REMOVE	3
  #define OPERATOR_MERGE	4
  #define OPERATOR_REDUCE	5


  struct tgem_NN {
      int 			operation;
      int    			arg1;
      int 			arg2;
  };
  
  struct tgem_GRAPH {
      std::vector<tgem_NODE>	nodes;
      std::vector<tgem_EDGE>	arcs;
      std::vector<tgem_NN> 	my_NN;
      double                    begin_obsrv;
      double                    end_obsrv;
  };

void run_and_test_TGEM();
void build_graph(tgem_GRAPH g);
void display_graph (tgem_GRAPH	g);
void compute_neighbours (tgem_GRAPH &g);
double compute_scoreBIC_independantNode(tgem_NODE &node, double begin, double end);
double compute_scoreBIC(tgem_NODE &node, double begin, double end);
double add_TS(tgem_GRAPH &_graph, int _src, int _dest, double _horizon, int _test);
double extend_TS(tgem_GRAPH &_graph, int _edgeID, int _test);
double split_TS(tgem_GRAPH &_graph, int _edgeID, int _tsID, int _test);

// ajout Mathilde
// void custom_display_graph (tgem_GRAPH	_graph);
// void build_small_graph (tgem_GRAPH 	&_graph);
// void display_graph (tgem_GRAPH	_graph);
void build_graphs(std::vector<tgem_GRAPH> &graphs, std::vector<std::string> paths_to_data, std::vector<std::map<std::string, int> > &labels2id);
void initialize_graph(tgem_GRAPH &g, std::string path_to_data, std::map<std::string, int> &label2id);
void parse_file(tgem_GRAPH &g,std::string path_to_data, std::map<std::string, int> &label2id);
std::vector<float> find_best_neighbour(std::vector<tgem_GRAPH> &graphs);
void custom_display_graph (tgem_GRAPH graph);
