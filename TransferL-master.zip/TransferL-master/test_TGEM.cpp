// =======================================================================================
// Author : LS2N > DUKe > PhJoalland
// Date   : [March to June 2019]
// =======================================================================================

#include "test_TGEM.h"

using namespace std;
using namespace boost;
using namespace PILGRIM;

// =======================================================================================
string node_id2label(int        _nodeid,
		     tgem_GRAPH _graph) {
// =======================================================================================

  if (_nodeid < 0 || _nodeid > _graph.nodes.size()) return("?");
  return(_graph.nodes[_nodeid].name);
}

// =======================================================================================
char node_id2label(int _nodeid) {
// =======================================================================================

  if (_nodeid == 0) return('A');
  if (_nodeid == 1) return('B');
  if (_nodeid == 2) return('C');
  if (_nodeid == 3) return('D');
  return('?');
}

// =======================================================================================
int node_label2id(char _nodelabel) {
// =======================================================================================

  if (_nodelabel == 'A') return(0);
  if (_nodelabel == 'B') return(1);
  if (_nodelabel == 'C') return(2);
  if (_nodelabel == 'D') return(3);
  return(-1);
}

// =================================================================================
//
void display_occurs (std::vector<double> _occurs) {
// =================================================================================

  std::cout << " occurs at [";
  for (int i = 0; i < _occurs.size(); i++) {
	std::cout << _occurs[i] << " ";
  }
  std::cout << "]" << std::endl;
}

// =================================================================================
//
void copy_occurs (std::vector<double>    _occsrc,
		  std::vector<double>   &_occdest) {
// =================================================================================

  //std::cout << "(copy_occurs) l'original AVANT :" << std::endl;
  //display_occurs(_occsrc);

  _occdest.clear();

  for (unsigned i = 0; i < _occsrc.size(); ++i) {
      double occ = _occsrc[i];
      _occdest.push_back(occ);
  }

  //std::cout << "(copy_occurs) la copie APRES :" << std::endl;
  //display_occurs(_occdest);
}

// =================================================================================
//
void display_causes (std::vector<tgem_TRIGGER> _causes) {
// =================================================================================

  for (int i = 0; i < _causes.size(); i++) {
	std::cout << (i+1) << "th cause : nbocc= " << _causes[i].nbocc
		           << "| duration= "       << _causes[i].duration
			   << std::endl;
  }
}

// =================================================================================
//
void copy_causes (std::vector<tgem_TRIGGER>    _causrc,
		  std::vector<tgem_TRIGGER>   &_caudest) {
// =================================================================================

  //std::cout << "(copy_causes) l'original AVANT :" << std::endl;
  //display_causes(_causrc);

  _caudest.clear();

  for (unsigned i = 0; i < _causrc.size(); ++i) {
      tgem_TRIGGER trig;
		   trig.nbocc    = _causrc[i].nbocc;
		   trig.duration = _causrc[i].duration;

      _caudest.push_back(trig);
  }

  //std::cout << "(copy_causes) la copie APRES :" << std::endl;
  //display_causes(_caudest);
}

// =================================================================================
//
void display_effects (std::vector<tgem_EFFECT>	_effects) {
// =================================================================================

  if (_effects.size() == 0) {
	std::cout << " no effects" << std::endl;
	return;
  }

  std::cout << "     EFFECTS    " << std::endl;
  std::cout << "|====|====|====|" << std::endl;
  std::cout << "|time|code|size|" << std::endl;
  std::cout << "|----|----|----|" << std::endl;
  for (unsigned i = 0; i < _effects.size(); ++i) {
      std::cout << "|" << _effects[i].time << "|" << _effects[i].code << "|" << _effects[i].size << "|" << std::endl;
  }
  std::cout << "|====|====|====|" << std::endl;
}

// =================================================================================
//
void copy_effects (std::vector<tgem_EFFECT>	_effsrc,
		   std::vector<tgem_EFFECT>    &_effdest) {
// =================================================================================

  //std::cout << "(copy_effects) l'original AVANT :" << std::endl;
  //display_effects(_effsrc);

  _effdest.clear();

  for (unsigned i = 0; i < _effsrc.size(); ++i) {
      tgem_EFFECT  eff;
		   eff.time = _effsrc[i].time;
		   eff.code = _effsrc[i].code;
		   eff.size = _effsrc[i].size;

      _effdest.push_back(eff);
  }

  //std::cout << "(copy_effects) la copie APRES :" << std::endl;
  //display_effects(_effdest);
}

// =======================================================================================
//
void display_tree(std::vector<tgem_TS>	_tree) {
// =======================================================================================

  std::cout << "-> " << _tree.size() << " TS in the tree = {" << std::endl;
  for (int i = 0; i < _tree.size(); i++) {
	std::cout << (i+1) << "th TS of its tree (" << _tree[i].min << "," << _tree[i].max << "]"
		  << " pere="   << _tree[i].parent
		  << " frere="  << _tree[i].brotherR
		  << " enfant=" << _tree[i].childL
		  << std::endl;
	//display_effects(_tree[i].effects);
  }
  std::cout << "}" << std::endl;
}

// =================================================================================
//
void copy_tree (std::vector<tgem_TS>   _treesrc,
		std::vector<tgem_TS>  &_treedest) {
// =================================================================================

  //std::cout << "(copy_tree) l'original AVANT :" << std::endl;
  //display_tree(_treesrc);

  _treedest.clear();

  for (unsigned i = 0; i < _treesrc.size(); ++i) {
      tgem_TS ts;
	      ts.min      = _treesrc[i].min;
	      ts.max      = _treesrc[i].max;
	      ts.parent   = _treesrc[i].parent;
	      ts.brotherR = _treesrc[i].brotherR;
	      ts.childL   = _treesrc[i].childL;
	      copy_effects (_treesrc[i].effects, ts.effects);

      _treedest.push_back(ts);
  }

  //std::cout << "(copy_tree) la copie APRES :" << std::endl;
  //display_tree(_treedest);
}

// =================================================================================
//
void display_followers (std::vector<int>	_followers) {
// =================================================================================

  if (_followers.size() == 0) {
	std::cout << " no followers" << std::endl;
	return;
  }
  std::cout << " followers are : ";
  for (int i = 0; i < _followers.size(); i++) {
	std::cout << "[" << _followers[i] << "] -> ";
  }
  // std::cout << std::endl;
}

// =================================================================================
//
void copy_followers (std::vector<int>    _follsrc,
		     std::vector<int>   &_folldest) {
// =================================================================================

  //std::cout << "(copy_followers) l'original AVANT :" << std::endl;
  //display_followers(_follsrc);

  _folldest.clear();

  for (unsigned i = 0; i < _follsrc.size(); ++i) {
      int follower = _follsrc[i];
      _folldest.push_back(follower);
  }

  //std::cout << "(copy_followers) la copie APRES :" << std::endl;
  //display_followers(_folldest);
}

// =================================================================================
//
void display_edge (tgem_GRAPH   _graph,
		   tgem_EDGE	_edge) {
// =================================================================================

  std::cout << "***********************************" << std::endl;
  std::cout << "               EDGE " 	
            << node_id2label(_edge.src, _graph) << "->" << node_id2label(_edge.dest, _graph) << std::endl;
  std::cout << "***********************************" << std::endl;
  display_tree     (_edge.tree);
  //display_followers(_edge.followers);
  //display_effects  (_edge.edge_effects);
  std::cout << "***********************************" << std::endl;
}

// =================================================================================
//
void display_edge (tgem_EDGE	_edge) {
// =================================================================================

  std::cout << "***********************************" << std::endl;
  std::cout << "               EDGE " 	
            << node_id2label(_edge.src) << "->" << node_id2label(_edge.dest) << std::endl;
  std::cout << "***********************************" << std::endl;
  display_tree     (_edge.tree);
  //display_followers(_edge.followers);
  //display_effects  (_edge.edge_effects);
  std::cout << "***********************************" << std::endl;
}

// =================================================================================
//
void copy_edge (tgem_EDGE   _edgesrc,
		tgem_EDGE  &_edgedest) {
// =================================================================================

  //std::cout << "(copy_edge) l'original AVANT :" << std::endl;
  //display_edge(_edgesrc);

  _edgedest.src  = _edgesrc.src;
  _edgedest.dest = _edgesrc.dest;
  copy_tree       (_edgesrc.tree,         _edgedest.tree);
  copy_followers  (_edgesrc.followers,    _edgedest.followers);
  copy_effects    (_edgesrc.edge_effects, _edgedest.edge_effects);

  //std::cout << "(copy_edge) la copie APRES :" << std::endl;
  //display_edge(_edgedest);
}

// =================================================================================
//
void display_parents (std::vector<int>	_parents_edges) {
// =================================================================================

  if (_parents_edges.size() == 0) {
	std::cout << " no parent edges" << std::endl;
	return;
  }

  std::cout << " parent edges are : ";
  for (int i = 0; i < _parents_edges.size(); i++) {
	std::cout << "[" << _parents_edges[i] << "] -> ";
  }
  // std::cout << std::endl;
}

// =================================================================================
//
void copy_parentsedges (std::vector<int>    _parsrc,
		        std::vector<int>   &_pardest) {
// =================================================================================

  //std::cout << "(copy_parentsedges) l'original AVANT :" << std::endl;
  //display_parents(_parsrc);

  _pardest.clear();

  for (unsigned i = 0; i < _parsrc.size(); ++i) {
      int parent_edge = _parsrc[i];
      _pardest.push_back(parent_edge);
  }

  //std::cout << "(copy_parentsedges) la copie APRES :" << std::endl;
  //display_parents(_pardest);
}

// =================================================================================
//
void display_node (tgem_NODE	_node) {
// =================================================================================

  std::cout << "***********************************" << std::endl;
  std::cout << "       NODE '" 	<< _node.name << "'" << std::endl;
  std::cout << "***********************************" << std::endl;
  std::cout << "-> score = " 	<< _node.score       << std::endl;

  display_occurs (_node.occurs);
  display_parents(_node.parents_edges);
  //display_effects(_node.parents_effects);
  display_causes (_node.causes);

  std::cout << "***********************************" << std::endl;
}

// =================================================================================
//
void copy_node (tgem_NODE   _nodesrc,
		tgem_NODE  &_nodedest) {
// =================================================================================

  //std::cout << "(copy_node) l'original AVANT :" << std::endl;
  //display_node(_nodesrc);

  _nodedest.name.assign(_nodesrc.name);
  _nodedest.score = _nodesrc.score;
  copy_occurs      (_nodesrc.occurs,          _nodedest.occurs);
  copy_parentsedges(_nodesrc.parents_edges,   _nodedest.parents_edges);
  copy_effects     (_nodesrc.parents_effects, _nodedest.parents_effects);
  copy_causes      (_nodesrc.causes,          _nodedest.causes);

  //std::cout << "(copy_node) la copie APRES :" << std::endl;
  //display_node(_nodedest);
}

// =================================================================================
//
void display_neighbour (tgem_GRAPH  _graph,
			tgem_NN	    _NN) {
// =================================================================================

  if      (_NN.operation == OPERATOR_ADD) {
	std::cout << "ADD \t";
	std::cout << node_id2label(_NN.arg1, _graph) << "->" << node_id2label(_NN.arg2, _graph);
  }

  else if (_NN.operation == OPERATOR_EXTEND) {
	std::cout << "EXTEND \t";
        int       edge_ID   = _NN.arg1;
        tgem_EDGE this_edge = _graph.arcs[edge_ID];
	std::cout << node_id2label(this_edge.src, _graph) << "->" << node_id2label(this_edge.dest, _graph);
  }
  else if (_NN.operation == OPERATOR_SPLIT) {
	std::cout << "SPLIT \t";
        int       edge_ID   = _NN.arg1;
        int       ts_ID     = _NN.arg2;
        tgem_EDGE this_edge = _graph.arcs[edge_ID];
	std::cout << node_id2label(this_edge.src, _graph) << "->" << node_id2label(this_edge.dest, _graph);
        tgem_TS this_ts = _graph.arcs[edge_ID].tree[ts_ID];
	std::cout << " TS[" << this_ts.min << "-" << this_ts.max << "]";	
  }
}

// =================================================================================
//
void display_graph (tgem_GRAPH	_graph) {
// =================================================================================

  std::cout 					  << std::endl;
  std::cout << "================================" << std::endl;
  std::cout << "= GRAPH NODES are              =" << std::endl;
  std::cout << "================================" << std::endl;

  for (int i = 0; i < _graph.nodes.size(); i++) {
	display_node(_graph.nodes[i]);
  }

  std::cout 					  << std::endl;
  std::cout << "================================" << std::endl;
  std::cout << "= GRAPH EDGES are              =" << std::endl;
  std::cout << "================================" << std::endl;

  for (int j = 0; j < _graph.arcs.size(); j++) {
	display_edge(_graph.arcs[j]);
  }
}

// =================================================================================
//
//  TIME	      CAUSES		  NODE.OCCURS		TS.EFFECTS
// ENDING    
//  |==|    |=======|===============|       |====|	     |====|====|====|
//  |60|    | nbocc |    duration   |	      | 23 |	     |time|code|size| size 2
//  |==|    |-------|---------------|       | 28 |	     |----|----|----|
//       [0]|   0   |(20- 0)+(TE-48)|  <=   | 32 |    AND    |  0 |  0 |  2 | 0 = 00
//       [1]|   3   |(38-20)+(48-40)|	      | 39 |     	     | 20 |  1 |  2 | 1 = 01
//       [2]|   1   |    (40-38)    |	      |====|	         | 38 |  2 |  2 | 2 = 10
//       [3]|   0   |       0       |		  	                 | 40 |  1 |  2 | 1 = 01
//          |=======|===============|   		                 | 48 |  0 |  2 | 0 = 00
//							     |====|====|====|
//
void compute_durations (tgem_NODE	         &_node,
		        std::vector<tgem_EFFECT>  _effects,
		        std::vector<double>       _occurs,
			double			  _begin,
			double			  _end) {
// =================================================================================

  // check
  _node.causes.clear();
  int E = _effects.size();
  int O = _occurs.size();
  if (E == 0) 			{std::cout << "ERROR(compute_durations) empty effects" 		<< std::endl; return;}
  double prev = _effects[0].time;
  if (prev != _begin) 		{std::cout << "ERROR(compute_durations) effect starting time" 	<< std::endl; return;}
  if (_effects[0].code != 0)	{std::cout << "ERROR(compute_durations) effect starting code" 	<< std::endl; return;}

  // create the empty causes
  int N = pow(2, _effects[0].size);
  for (int i = 0; i < N; i++) {
      tgem_TRIGGER trigger;
                   trigger.nbocc = 0;
                   trigger.duration = 0.0;
      _node.causes.push_back(trigger);
  }

  // compute the durations
  for (int e = 1; e < E; e++) {
     double next = _effects[e].time;
     if (next > _end) next = _end; 
     _node.causes[_effects[e-1].code].duration += (next - prev);
     prev = next;
  }
  _node.causes[0].duration += (_end - prev);

  // compute the nb of occurrences
  int e = 0;
  for (int o = 0; o < O; o++) {

     while (_effects[e].time < _occurs[o] && e < E) e++;
     _node.causes[_effects[e-1].code].nbocc ++;
  }
}

// =================================================================================
//
//		   TS			  NODE.OCCURS		TS.EFFECTS
//
//          |====|====|====|     	    |====|	     |====|====|====|
//          | min| max| ...|		    | 20 |	     |time|code|size| size 1
//  USING   |----|----|----|     	    | 25 |	     |----|----|----|
//          |  8 | 16 | ...| 	  AND       | 30 |     =>    |  0 |  0 |  1 | 0 = 0
//          |====|====|====|		    | 40 |     	     | 28 |  1 |  1 | 1 = 1
//          				    |====|	     | 46 |  0 |  1 | 0 = 0
//          					  	     | 48 |  1 |  1 | 1 = 1
//          						     | 56 |  0 |  1 | 0 = 0
//							     |====|====|====|
//
void create_effects (tgem_TS		      &_ts,
		     double		       _begin,
		     std::vector<double>       _occurs) {
// =================================================================================

  double prev = _begin;
  double next = _begin;
  bool   goon = true;
  int    j    = 0;
  int    N    = _occurs.size();

  while (goon) {

	if (j < N) next = _occurs[j] + _ts.min;

	// dealing with FIRST
	if (j == 0) {
		tgem_EFFECT eff;
			    eff.time = _begin;
			    eff.code = 0;
			    eff.size = 1;
		_ts.effects.push_back(eff);

		tgem_EFFECT eff2;
			    eff2.time = next;
			    eff2.code = 1;
			    eff2.size = 1;
		_ts.effects.push_back(eff2);
	}

	// dealing with LAST
	else if (j >= N) {
		tgem_EFFECT eff;
			    eff.time = prev + _ts.max - _ts.min;
			    eff.code = 0;
			    eff.size = 1;
		_ts.effects.push_back(eff);
		goon = false;
	}

	// dealing with OTHERS
	else if (prev + _ts.max - _ts.min < next) {
		tgem_EFFECT eff;
			    eff.time = prev + _ts.max - _ts.min;
			    eff.code = 0;
			    eff.size = 1;
		_ts.effects.push_back(eff);

		tgem_EFFECT eff2;
			    eff2.time = next;
			    eff2.code = 1;
			    eff2.size = 1;
		_ts.effects.push_back(eff2);
	}

	// dealing with NEXT
	j++;
	prev = next;
  }
}

// =====================================================================================================
//
//		effects1			effects2			effects3
//
//          |====|====|====|     	    |====|====|====|		     |====|====|====|
//          |time|code|size|		    |time|code|size|		     |time|code|size| size 3 = 1 + 2
//          |----|----|----|     	    |----|----|----|		     |----|----|----|
// MERGING  |  0 |  0 |  1 | 0 = 0    AND   |  0 |  0 |  2 | 0 = 00    =>    |  0 |  0 |  3 | 0 = 000
//          | 20 |  1 |  1 | 1 = 1    	    | 25 |  2 |  2 | 3 = 10	     | 20 |  4 |  3 | 4 = 100
//          | 30 |  0 |  1 | 0 = 0    	    | 28 |  3 |  2 | 3 = 11	     | 25 |  6 |  3 | 6 = 110
//          | 50 |  1 |  1 | 1 = 1    	    | 40 |  0 |  2 | 0 = 00	     | 28 |  7 |  3 | 7 = 111
//          | 60 |  0 |  1 | 0 = 0    	    |====|====|====|		     | 30 |  3 |  3 | 3 = 011
//          |====|====|====|						     | 40 |  0 |  3 | 0 = 000
//									     | 50 |  4 |  3 | 4 = 100
//									     | 60 |  0 |  3 | 0 = 000
//									     |====|====|====|
//
void merge_effects (std::vector<tgem_EFFECT>     _effectsA,
		    std::vector<tgem_EFFECT>     _effectsB,
		    std::vector<tgem_EFFECT>    &_effectsAB,
		    double			 _begin) {
// =====================================================================================================

  double next    = _begin;
  double time1   = _begin;
  double time2   = _begin;
  int    code1   = 0;
  int    code2   = 0;
  int    size1   = 0;
  int    size2   = 0;

  _effectsAB.clear();

  int    i1    = 0;
  int    i2    = 0;
  int    N1    = _effectsA.size();
  int    N2    = _effectsB.size();

  if (N1*N2 == 0) {std::cout << "ERROR(merge_effects) N1 = " << N1 << ", N2 = " << N2 << std::endl; return;}

  while (i1 < N1 || i2 < N2) {

	if (i1 < N1) {time1 = _effectsA[i1].time;  size1 = _effectsA[i1].size;}
	if (i2 < N2) {time2 = _effectsB[i2].time;  size2 = _effectsB[i2].size;}

	if 	(time1  < time2) {
		next    = time1;
		code1 = _effectsA[i1].code;
		i1++;
	}

	else if (time1  > time2) {
		next    = time2;
		code2   = _effectsB[i2].code;
		i2++;
	}

	else if (time1 == time2) {
		next    = time1;
		code1   = _effectsA[i1].code;
		code2   = _effectsB[i2].code;
		i1++;
		i2++;
	}

	if (i1 >= N1) time1 = TIME_MAX;
	if (i2 >= N2) time2 = TIME_MAX;

        tgem_EFFECT effect;
	        effect.time = next;
	        effect.code = code1 * pow(2, size2) + code2;
	        effect.size = size1 + size2;
	_effectsAB.push_back(effect);
   }
}

// =======================================================================================
int root_TS(std::vector<tgem_TS>     _tree) {
// =======================================================================================

  if (_tree.size() == 0) return(-1);

  int     id = 0;
  tgem_TS ts = _tree[id];
  bool  goon = (ts.parent != -1);

  while (goon) {
	id = ts.parent;
	ts = _tree[id];
	goon = (ts.parent != -1);
  }

  return(id);
}

// =======================================================================================
int number_tree(tgem_EDGE     &_edge,
	        int	       _ts,
	        int            _rank) {
// =======================================================================================

  //std::cout << "*** number_tree => TS[" << _ts << "] with RANK = " << _rank << std::endl;

  int ts   = _ts;
  int rank = _rank;

  if (rank == -1) { // INITIALLY UP TO THE ROOT
     _edge.followers.clear();
     ts = root_TS(_edge.tree);
     //std::cout << "number_tree => ROOT : TS[" << ts << "]" << std::endl;
     if (ts < 0) {std::cout << "ERROR(numbering)" << std::endl; return(-1);}
     rank++;
  }

  if (_edge.tree[ts].childL == -1) {
	_edge.followers.push_back(ts);
	//std::cout << (rank+1) << "th (" << _edge.tree[ts].min << "," << _edge.tree[ts].max << "]" << std::endl;
	rank++;
  }
  else 					rank = number_tree(_edge, _edge.tree[ts].childL,   rank);
  if (_edge.tree[ts].brotherR != -1)	rank = number_tree(_edge, _edge.tree[ts].brotherR, rank);

  return(rank);
}

// =======================================================================================
std::vector<tgem_EFFECT> merge_tree(tgem_EDGE _edge,
				    double    _begin) {
// =======================================================================================

  int N = _edge.followers.size();
  if (N < 2) {
	if (N > 0) return(_edge.tree[_edge.followers[0]].effects);
	std::cout << "ERROR(merge_tree) : no effects" << std::endl;
	std::vector<tgem_EFFECT> empty_effects;
	return(empty_effects);
  }

  std::vector<tgem_EFFECT> effects0, effects1;
  merge_effects(_edge.tree[_edge.followers[0]].effects, _edge.tree[_edge.followers[1]].effects, effects0, _begin);	
  for (int i = 2; i < N; i++) {
	if (i % 2 > 0)	merge_effects(effects1, _edge.tree[_edge.followers[i]].effects, effects0, _begin);
	else		merge_effects(effects0, _edge.tree[_edge.followers[i]].effects, effects1, _begin);
  }

  if (N % 2 > 0) return(effects1);
  return(effects0);
}

// =================================================================================
//
double get_horizon (tgem_EDGE  &_edge) {
// =================================================================================

  int rank = number_tree(_edge, 0, -1);

  int last = _edge.followers.size() - 1;
  if (last < 0) return(-1.0);
  int id_TS = _edge.followers[last];

  return(_edge.tree[id_TS].max);
}

// =======================================================================================
//
double compute_scoreBIC_independantNode(tgem_NODE &_node,
                                        double     _begin,
                                        double     _end) {
// =======================================================================================

  int     nbocc       = _node.occurs.size();
  double  lambda      = nbocc / (_end - _begin);
  double  score       = log(pow(lambda, nbocc)) - lambda*(_end - _begin) - log(_end - _begin); 
  return(score);
}

// =======================================================================================
//
double compute_scoreBIC(tgem_NODE &_node,
                        double     _begin,
                        double     _end) {
// =======================================================================================

  double                cumul    = 0.0;
  vector<tgem_TRIGGER> 	triggers = _node.causes;
 
  // std::cout << std::endl;
  for (int i = 0; i < triggers.size(); i++) {
    double lambda       = 0.0;
    if (triggers[i].duration > 0.0) lambda = triggers[i].nbocc / triggers[i].duration;
    double delta_i  = log(pow(lambda, triggers[i].nbocc)) - lambda*triggers[i].duration; 
    // std::cout << "\t\t(compute_scoreBIC) : " << (i+1)
    //           << "th config -> nbocc=" << (triggers[i].nbocc)
    //           << ", duration="         << (triggers[i].duration)
    //           << ", lambda="           << lambda
    //           << " => delta "          << delta_i
    //           << std::endl;
    cumul += delta_i;
  }

  double  log_last = log(_end - _begin);
  // std::cout << "\t\t ---------------------------------------------------" << std::endl;
  // std::cout << "\t\t(compute_scoreBIC) : cumul - penalty =" << cumul
  //                            << " - "			    << (triggers.size() * log_last)
	// 		     << " = "           	    << (cumul - triggers.size() * log_last)
	// 		     << " (previous score was "     << (_node.score)
	// 		     << ")"       		    << std::endl;

  return(cumul - triggers.size() * log_last - _node.score);
}

// =======================================================================================
double update_effects(tgem_GRAPH    &_graph,
	     	      int            _src,
	    	      int	     _dest,
		      int	     _edgeID) {
// =======================================================================================

  // compute the Effects of a Node from its parent Edges and their own effects
  int N = _graph.nodes[_dest].parents_edges.size();

  if (N < 2) {
	if (N > 0) copy_effects(_graph.arcs[_edgeID].edge_effects, _graph.nodes[_dest].parents_effects);
	else {std::cout << "ERROR(extend_TS) : no effects" << std::endl; return(-1.0);}
  }

  else {
	int       edge0_ID = _graph.nodes[_dest].parents_edges[0];
	tgem_EDGE edge0    = _graph.arcs[edge0_ID];
  	int       edge1_ID = _graph.nodes[_dest].parents_edges[1];
  	tgem_EDGE edge1    = _graph.arcs[edge1_ID];

  	std::vector<tgem_EFFECT> effects0, effects1;
  	merge_effects(edge0.edge_effects, edge1.edge_effects, effects0, _graph.begin_obsrv);	

  	for (int i = 2; i < N; i++) {
		int 	  edge_id   = _graph.nodes[_dest].parents_edges[i]; 
		tgem_EDGE this_edge = _graph.arcs[edge_id];
		if (i % 2 > 0)	merge_effects(effects1, this_edge.edge_effects, effects0, _graph.begin_obsrv);
		else		merge_effects(effects0, this_edge.edge_effects, effects1, _graph.begin_obsrv);
  	}

  	if (N % 2 > 0) copy_effects(effects1, _graph.nodes[_dest].parents_effects);
  	else 	       copy_effects(effects0, _graph.nodes[_dest].parents_effects);
  }

  // Compute the NbOcc and Durations
  compute_durations(_graph.nodes[_dest], _graph.nodes[_dest].parents_effects, _graph.nodes[_dest].occurs, _graph.begin_obsrv, _graph.end_obsrv);

  // Compute the Score
  double score = compute_scoreBIC(_graph.nodes[_dest], _graph.begin_obsrv, _graph.end_obsrv);
  _graph.nodes[_dest].score += score;
  return(score);
}
// TODO voir comment renvoyer graph pour utiliser changement pour générer voisins, bests, etc
// =======================================================================================
double add_TS(tgem_GRAPH &_graph, int _src, int _dest, double _horizon, int _test) {
// =======================================================================================

  tgem_EDGE new_edge;
            new_edge.src  = _src;
	          new_edge.dest = _dest;
      	    new_edge.tree.clear();
      	    new_edge.followers.clear();
            new_edge.edge_effects.clear();

  tgem_TS TSadd;
          TSadd.min  	 = 0.0;
          TSadd.max 	 = _horizon;
          TSadd.parent 	 = -1;
          TSadd.brotherR = -1;
          TSadd.childL	 = -1;

  create_effects(TSadd, _graph.begin_obsrv, _graph.nodes[_src].occurs);
  new_edge.tree.push_back(TSadd);

  int rank = number_tree(new_edge, 0, -1);
  new_edge.edge_effects = merge_tree(new_edge, _graph.begin_obsrv);

  int new_edgeID = _graph.arcs.size();
  _graph.arcs.push_back(new_edge);

  tgem_NODE node_before;
  if (_test == TEST_NEIGHBOUR) copy_node(_graph.nodes[_dest], node_before);
  _graph.nodes[_dest].parents_edges.push_back(new_edgeID);

  // update the Effects of a Node from its parent Edges and their own effects
  double score = update_effects(_graph, _src, _dest, new_edgeID);

  if (_test == CHOOSE_NEIGHBOUR) {

	  // update the Neighbours
    tgem_NN   	 NN;
    NN.operation = OPERATOR_EXTEND;
    NN.arg1      = new_edgeID;
    NN.arg2      = -1;
    _graph.my_NN.push_back(NN);

    NN.operation = OPERATOR_SPLIT;
    NN.arg1      = new_edgeID;
    NN.arg2      = 0;
    _graph.my_NN.push_back(NN);
  } else {
  	_graph.arcs.pop_back();
	  copy_node(node_before, _graph.nodes[_dest]);
  }

  return(score);
}

// =======================================================================================
double  extend_TS(tgem_GRAPH &_graph, int _edgeID, int _test) {
// =======================================================================================

  int src        = _graph.arcs[_edgeID].src;
  int dest       = _graph.arcs[_edgeID].dest;
  int id_root = root_TS(_graph.arcs[_edgeID].tree);
  if (id_root < 0) {std::cout << "ERROR(extend)" << std::endl; return(-1.0);}
 
  tgem_TS TSparent;
  	  TSparent.min  	 = -1;
  	  TSparent.max 	 	 = -1;
	    TSparent.parent 	 = -1;
  	  TSparent.brotherR	 = -1;
  	  TSparent.childL	 = id_root;

  tgem_EDGE edge_before;
  tgem_NODE node_before;
  if (_test == TEST_NEIGHBOUR) {
    copy_edge(_graph.arcs[_edgeID], edge_before);
    copy_node(_graph.nodes[dest], node_before);
  }

  _graph.arcs[_edgeID].tree[id_root].parent     = _graph.arcs[_edgeID].tree.size();
  _graph.arcs[_edgeID].tree.push_back(TSparent);

  tgem_TS TSbrotherR;
  	  TSbrotherR.min  	 = get_horizon(_graph.arcs[_edgeID]);
  	  TSbrotherR.max 	 = 2*TSbrotherR.min;
	    TSbrotherR.parent 	 = _graph.arcs[_edgeID].tree.size() - 1;
  	  TSbrotherR.brotherR	 = -1;
  	  TSbrotherR.childL	 = -1;
  create_effects(TSbrotherR, _graph.begin_obsrv, _graph.nodes[src].occurs);
  _graph.arcs[_edgeID].tree[id_root].brotherR   = _graph.arcs[_edgeID].tree.size();
  _graph.arcs[_edgeID].tree.push_back(TSbrotherR);

  // compute the Edge Effects
  std::vector<tgem_EFFECT>  new_effects;
  new_effects.clear();
  merge_effects(TSbrotherR.effects, _graph.arcs[_edgeID].edge_effects, new_effects, _graph.begin_obsrv);
  copy_effects(new_effects, _graph.arcs[_edgeID].edge_effects);

  // update the Effects of a Node from its parent Edges and their own effects
  double score = update_effects(_graph, src, dest, _edgeID);

  if (_test == CHOOSE_NEIGHBOUR) {

    // update the Neighbours
    tgem_NN   	 NN;
    NN.operation = OPERATOR_EXTEND;
    NN.arg1      = _edgeID;
    NN.arg2      = -1;
    _graph.my_NN.push_back(NN);

    NN.operation = OPERATOR_SPLIT;
    NN.arg1      = _edgeID;
    NN.arg2      = _graph.arcs[_edgeID].tree.size() - 1;
    _graph.my_NN.push_back(NN);
  }

  else {
	copy_edge(edge_before, _graph.arcs[_edgeID]);
	copy_node(node_before, _graph.nodes[dest]);
  }

  return(score);
}

// =======================================================================================
double split_TS(tgem_GRAPH &_graph, int _edgeID, int _tsID, int _test) {
// =======================================================================================

  int src        = _graph.arcs[_edgeID].src;
  int dest       = _graph.arcs[_edgeID].dest;

  if (_tsID < 0 || _tsID >= _graph.arcs[_edgeID].tree.size()) {std::cout << "ERROR(split)" << std::endl; return(-1.0);}

  tgem_TS TSparent = _graph.arcs[_edgeID].tree[_tsID];
  
  tgem_TS TSchildL;
  	  TSchildL.min  	 = TSparent.min;
  	  TSchildL.max 	 	 = (TSparent.min + TSparent.max) / 2.0;
	  TSchildL.parent 	 = _tsID;
  	  TSchildL.brotherR	 = -1;
  	  TSchildL.childL	 = -1;
  create_effects(TSchildL, _graph.begin_obsrv, _graph.nodes[src].occurs);

  tgem_EDGE old_edge;
  tgem_NODE old_node;
  if (_test == TEST_NEIGHBOUR) {
	copy_edge(_graph.arcs[_edgeID], old_edge);
	copy_node(_graph.nodes[dest],   old_node);
  }

  _graph.arcs[_edgeID].tree[_tsID].childL = _graph.arcs[_edgeID].tree.size();
  _graph.arcs[_edgeID].tree.push_back(TSchildL);

  tgem_TS TSchildR;
  	  TSchildR.min  	 = (TSparent.min + TSparent.max) / 2.0;
  	  TSchildR.max 	 	 = TSparent.max;
	  TSchildR.parent 	 = _tsID;
  	  TSchildR.brotherR	 = -1;
  	  TSchildR.childL	 = -1;

  create_effects(TSchildR, _graph.begin_obsrv, _graph.nodes[src].occurs);
  _graph.arcs[_edgeID].tree[_graph.arcs[_edgeID].tree.size() - 1].brotherR = _graph.arcs[_edgeID].tree.size();
  _graph.arcs[_edgeID].tree.push_back(TSchildR);

  // compute the Edge Effects
  std::vector<tgem_EFFECT>  new_effects;
  new_effects.clear();
  int rank = number_tree(_graph.arcs[_edgeID], 0, -1);
  _graph.arcs[_edgeID].edge_effects = merge_tree(_graph.arcs[_edgeID], _graph.begin_obsrv);

  // update the Effects of a Node from its parent Edges and their own effects
  double score = update_effects(_graph, src, dest, _edgeID);

  if (_test == CHOOSE_NEIGHBOUR) {

	  // update the Neighbours
	  tgem_NN   	 NN;
	  		 NN.operation = OPERATOR_SPLIT;
	  		 NN.arg1      = _edgeID;
		 	 NN.arg2      = _graph.arcs[_edgeID].tree.size() - 2;
	  _graph.my_NN.push_back(NN);

	  		 NN.operation = OPERATOR_SPLIT;
	  		 NN.arg1      = _edgeID;
		 	 NN.arg2      = _graph.arcs[_edgeID].tree.size() - 1;
	  _graph.my_NN.push_back(NN);
  }

  else {
	copy_edge(old_edge, _graph.arcs[_edgeID]);
	copy_node(old_node, _graph.nodes[dest]);
  }

  return(score);
}

// =================================================================================
//
void read_input (tgem_GRAPH 	&_graph) {
// =================================================================================

  char filename[FILENAME_MAX];
  std::strcpy(filename, "***********************************************");

  std::cout << "Enter the path to the data file: ... (/home/admin-ls2n/Pilgrim/General/build/usecases/essai.csv)" << std::endl;
  std::cin >> filename;

  _graph.begin_obsrv = 0.0;
  _graph.end_obsrv   = 0.0;
  bool initialized   = false;
  bool flag = false;
  do { //do
	std::ifstream file(filename);
	if (file) {
    flag = true;
    string line;
    int row = 0;
    while (getline(file, line)) {

		 int linelen = line.length();

      //std::cout << (row+1) << "th line = '" << line << "' is " << linelen << " characters long"<< std::endl;

		 // first line of the file <=> the Labels of the nodes
		 if (row == 0) {
        string label = "";    
        char next_char;
        int ChrCount = 0;

        while (ChrCount < linelen) {
          char next_char = line[ChrCount];       
          ChrCount++;
            //cout << ChrCount << "th char of this line = " << next_char << endl;

          if (ChrCount == linelen) {
            label.append(1u, next_char);
            tgem_NODE new_node;
            new_node.name.assign(label);
            new_node.score = 0.0;
            _graph.nodes.push_back(new_node);
          }

          else if (next_char == '"') {;}

          else if (next_char == ';') {
            tgem_NODE new_node;
            new_node.name.assign(label);
            new_node.score = 0.0;
            _graph.nodes.push_back(new_node);
            label.clear();
          }

          else	label.append(1u, next_char);
        }
		 }

		 // next lines of the file <=> the events timestamps
		 else {
		        string time = "0";
		        char   next_char;
		        int    ChrCount = 0;
			int    column = 0;

		        while (ChrCount < linelen) {
            			char next_char = line[ChrCount];       
		                ChrCount++;
	         		//cout << ChrCount << "th char of this line = " << next_char << endl;

				if (ChrCount == linelen) {
					time.append(1u, next_char);
	         		//std::cout << "final node " << (_graph.nodes[column].name)
				//     << "has  " << (_graph.nodes[column].occurs.size()+1)
				//     << "th timestamp = " << (atof(time.c_str())) << std::endl;
					double this_time = atof(time.c_str());
					if (! initialized) {
					   initialized = true;
					   _graph.begin_obsrv = this_time - OBSRV_EPSILON;
					   if (_graph.begin_obsrv < 0.0) _graph.begin_obsrv = 0.0;
					}
					else if (this_time < _graph.begin_obsrv) {
					   _graph.begin_obsrv = this_time - OBSRV_EPSILON;
					   if (_graph.begin_obsrv < 0.0) _graph.begin_obsrv = 0.0;
					}

					if (this_time > _graph.end_obsrv) _graph.end_obsrv = this_time;
					_graph.nodes[column].occurs.push_back(this_time);
				}

				else if (next_char == ';') {
	         		//cout << "node " << (_graph.nodes[column].name)
				//     << "has  " << (_graph.nodes[column].occurs.size()+1)
				//     << "th timestamp = " << (atof(time.c_str())) << endl;
					if (atof(time.c_str()) > 0.0) {
						double this_time = atof(time.c_str());
						if (! initialized) {
						   initialized = true;
						   _graph.begin_obsrv = this_time - 0.1;
						   if (_graph.begin_obsrv < 0.0) _graph.begin_obsrv = 0.0;
						}
						else if (this_time < _graph.begin_obsrv) {
						   _graph.begin_obsrv = this_time - 0.1;
						   if (_graph.begin_obsrv < 0.0) _graph.begin_obsrv = 0.0;
						}
						if (this_time > _graph.end_obsrv) _graph.end_obsrv = this_time;
						_graph.nodes[column].occurs.push_back(this_time);
					}
					time.clear();
					time.assign("0");
					column++;
				}

				else 	time.append(1u, next_char);
			}
		 }

		 row++;
    }
	}

        else cout << "ERROR(read_input) : cannot open this file" << endl;

  } while (!flag);

  _graph.end_obsrv = _graph.end_obsrv + OBSRV_EPSILON;
  for (int i = 0; i < _graph.nodes.size(); i++) {
	  _graph.nodes[i].score = compute_scoreBIC_independantNode(_graph.nodes[i], _graph.begin_obsrv, _graph.end_obsrv);
  }
}

// =================================================================================
//
void init_graph (tgem_GRAPH 	&_graph) {
// =================================================================================

  // ---------
  // THE NODES
  // ---------

  _graph.nodes.clear();
  _graph.arcs.clear();
  _graph.my_NN.clear();

  read_input(_graph);

  // ---------
  // THE EDGES
  // ---------
  // ---> NONE

  std::cout << "graph was initialized ... and observations from " << _graph.begin_obsrv << " to " << _graph.end_obsrv << std::endl;
}

// =================================================================================
//
void compute_neighbours (tgem_GRAPH 	&_graph) {
// =================================================================================

  // Clear the Neighbours Table
  _graph.my_NN.clear();

  // Find the Existing Edges
  int  N = _graph.nodes.size();
  int  existing_edge[N][N] = {-1};
  for (int i = 0; i < N; i++) {
      for (int j = 0; j < N; j++) existing_edge[i][j] = -1;
  }

  int  E = _graph.arcs.size();
  for (int e = 0; e < E; e++) {

      int src  = _graph.arcs[e].src;
      int dest = _graph.arcs[e].dest;
      existing_edge[src][dest] = e;
      std::cout << "existing edge[" << e << "] : " << node_id2label(src, _graph) << "->" << node_id2label(dest, _graph) << std::endl;
  }
  // N : number of nodes
  // K : number of active edges
  // T : mean number of active TS per edge tree

  // ADD    :   N² - K neighbours
  // EXTEND :   K      neighbours
  // SPLIT  : ~ K.T    neighbours

  // For every Nodes of the Graph
  for (int src = 0; src < N; src++) {
      for (int dest = 0; dest < N; dest++) {

		// Find ADD Neighbours (non existing edge)
		if (existing_edge[src][dest] < 0) {

			tgem_NN		 NN;
			       		 NN.operation = OPERATOR_ADD;
			       		 NN.arg1      = dest;
			       		 NN.arg2      = src;
			 _graph.my_NN.push_back(NN);
		}

		// Find EXTEND or SPLIT Neighbours (existing edge)
		else {

			int              edgeID    = existing_edge[src][dest];     
			tgem_EDGE	 this_edge = _graph.arcs[edgeID];

			tgem_NN   	 NN;
					 NN.operation = OPERATOR_EXTEND;
					 NN.arg1      = edgeID;
					 NN.arg2      = -1;
			_graph.my_NN.push_back(NN);

			for (int k = 0; k < this_edge.followers.size(); k++) {

						 NN.operation = OPERATOR_SPLIT;
						 NN.arg1      = edgeID;
						 NN.arg2      = this_edge.followers[k];
				_graph.my_NN.push_back(NN);
			}
		}
      }
  }
  // std::cout << "neighbours of the graph were computed... " << std::endl;
}

// =======================================================================================
void run_and_test_TGEM() {
// =======================================================================================

  std::cout << "---------------------- " << std::endl;
  std::cout << "          RTGEM        " << std::endl;
  std::cout << "---------------------- " << std::endl;
  
  tgem_GRAPH my_gem;

  init_graph(my_gem);
  double hrz;
  std::cout << "Enter the horizon (4 <=> ADD(0,4]) : ";
  std::cin >> hrz;

  compute_neighbours(my_gem);
  display_graph(my_gem);
  double graph_score = 0.0;
  for (int i = 0; i < my_gem.nodes.size(); i++) {
	  graph_score += my_gem.nodes[i].score;
  }
  std::cout << "     //*************************************************//" << std::endl;
  std::cout << "              INITIAL Graph score :" << graph_score         << std::endl;
  std::cout << "     //*************************************************//" << std::endl;

  menu :

  double best_score;
  int    best_id    = -1;
	bool   best_done = false;

	std::cout 					<< std::endl;
	std::cout << "================================" << std::endl;
	std::cout << "= NEIGHBOURS of this graph are =" << std::endl;
	std::cout << "================================" << std::endl;

	for (int choice = 0; choice < my_gem.my_NN.size(); choice++) {

		tgem_NN this_NN = my_gem.my_NN[choice];
		display_neighbour(my_gem, this_NN);
    double score = graph_score;

    if (this_NN.operation == OPERATOR_ADD)         score = add_TS(my_gem, this_NN.arg1, this_NN.arg2, hrz, TEST_NEIGHBOUR);
		else if (this_NN.operation == OPERATOR_EXTEND) score = extend_TS(my_gem, this_NN.arg1, TEST_NEIGHBOUR);
		else if (this_NN.operation == OPERATOR_SPLIT)  score = split_TS(my_gem, this_NN.arg1, this_NN.arg2, TEST_NEIGHBOUR);

    std::cout << " \t\t ==========> GAIN :" << score << std::endl;
		if (!best_done) {
			best_done = true;
			best_score = score;
			best_id    = choice;
		}
    else if (score > best_score) {
			best_score = score;
			best_id    = choice;
    }
  }

	if (best_score <= 0.0) {
	        std::cout << "     //*************************************************//" << std::endl;
	        std::cout << "              FINAL Graph score :" << graph_score           << std::endl;
	        std::cout << "     //*************************************************//" << std::endl;
		display_graph(my_gem);
		return;
	}

	tgem_NN this_NN = my_gem.my_NN[best_id];
  double score = 0.0;
  if      (this_NN.operation == OPERATOR_ADD)    score = add_TS(my_gem, this_NN.arg1, this_NN.arg2, hrz, CHOOSE_NEIGHBOUR);
	else if (this_NN.operation == OPERATOR_EXTEND) score = extend_TS(my_gem, this_NN.arg1, CHOOSE_NEIGHBOUR);
	else if (this_NN.operation == OPERATOR_SPLIT)  score = split_TS(my_gem, this_NN.arg1, this_NN.arg2, CHOOSE_NEIGHBOUR);
	graph_score += score;

  std::cout << "     //*************************************************//" << std::endl;
  std::cout << "\t";
  display_neighbour(my_gem, this_NN);
  std::cout << " => Graph score is now :" << graph_score                    << std::endl;
  std::cout << "     //*************************************************//" << std::endl;
	my_gem.my_NN.erase(my_gem.my_NN.begin() + best_id);

	goto menu;
}

//, Set::operation op
std::vector<float> find_best_neighbour(std::vector<tgem_GRAPH> &graphs){
  std::vector<float> best_scores; // no need to store indices, only scores

  double graph_score, best_score;
	bool   best_done = false;
  double hrz = 5; // horizon

  for (int model = 0; model < graphs.size(); model++){
    compute_neighbours(graphs[model]);
    // compute current scores
    graph_score = 0.0;
    for (int i = 0; i < graphs[model].nodes.size(); i++) {
      graph_score += graphs[model].nodes[i].score;
    }

    // int potential_operator = op.first.first;
    // changer ici pour qu'on applique que l'operation proposée
    for (int choice = 0; choice < graphs[model].my_NN.size(); choice++) {

      tgem_NN this_NN = graphs[model].my_NN[choice];
      double score = graph_score;

      if (this_NN.operation == OPERATOR_ADD)         score = add_TS(graphs[model], this_NN.arg1, this_NN.arg2, hrz, TEST_NEIGHBOUR);
      else if (this_NN.operation == OPERATOR_EXTEND) score = extend_TS(graphs[model], this_NN.arg1, TEST_NEIGHBOUR);
      else if (this_NN.operation == OPERATOR_SPLIT)  score = split_TS(graphs[model], this_NN.arg1, this_NN.arg2, TEST_NEIGHBOUR);

      if (!best_done) {
        best_done = true;
        best_score = score;
      } else if (score > best_score) {
        best_score = score;
      }
    }
    // std::cout << "Best score model " << model << ": " << best_score << std::endl;
    best_scores.push_back(best_score);   
    // std::cout << "and from vector: " << best_scores[model] << std::endl;
  }
  return best_scores;
}



void build_graphs(std::vector<tgem_GRAPH> &graphs, std::vector<std::string> paths_to_data, std::vector<std::map<std::string, int> > &labels2id){

  for (int i = 0; i < graphs.size(); i++){
    graphs[i].nodes.clear();
    graphs[i].arcs.clear();
    graphs[i].my_NN.clear();

    initialize_graph(graphs[i], paths_to_data[i], labels2id[i]);
  }
}

void initialize_graph(tgem_GRAPH &g, std::string path_to_data, std::map<std::string, int> &label2id) {
// =================================================================================

  g.nodes.clear();
  g.arcs.clear();
  g.my_NN.clear();

  parse_file(g, path_to_data, label2id);

  std::cout<< "graph initialized... and observations from " << g.begin_obsrv << " to " << g.end_obsrv << std::endl;
}

void parse_file(tgem_GRAPH &g,std::string path_to_data, std::map<std::string, int> &label2id){

    g.begin_obsrv = 0.0;
    g.end_obsrv   = 0.0;
    bool initialized   = false;
    bool flag = false;
    do { //do
      std::ifstream file(path_to_data);
      if (file) {
        flag = true;
        string line;
        int row = 0;
        while (getline(file, line)) {

          int linelen = line.length();

          //std::cout << (row+1) << "th line = '" << line << "' is " << linelen << " characters long"<< std::endl;

          // first line of the file <=> the Labels of the nodes
          if (row == 0) {
            string label = "";    
            char   next_char;
            int    ChrCount = 0;

            while (ChrCount < linelen) {
              char next_char = line[ChrCount];       
              ChrCount++;
              //cout << ChrCount << "th char of this line = " << next_char << endl;

              if (ChrCount == linelen) { // if end of row

                // label.append(1u, next_char); // adds an empty character at the end of the label
                tgem_NODE new_node;
                new_node.name.assign(label);
                new_node.score = 0.0;

                // std::cout << "label " << label << std::endl;
                // std::cout << "g.nodes.size() " << g.nodes.size() << std::endl;
                label2id[label] = g.nodes.size();

                g.nodes.push_back(new_node);
              } 
              else if (next_char == '"') {;}
              else if (next_char == ';') {
                tgem_NODE new_node;
                new_node.name.assign(label);
                new_node.score = 0.0;

                label2id[label] = g.nodes.size();

                g.nodes.push_back(new_node);
                label.clear();
              }
              else label.append(1u, next_char);
            }
          }

          // next lines of the file <=> the events timestamps
          else {
            string time = "0";
            char   next_char;
            int    ChrCount = 0;
            int    column = 0;

            while (ChrCount < linelen) {
              char next_char = line[ChrCount];       
              ChrCount++;
              //cout << ChrCount << "th char of this line = " << next_char << endl;

              if (ChrCount == linelen) {
                time.append(1u, next_char);
                //std::cout << "final node " << (g.nodes[column].name)
                //     << "has  " << (g.nodes[column].occurs.size()+1)
                //     << "th timestamp = " << (atof(time.c_str())) << std::endl;
                double this_time = atof(time.c_str());
                if (! initialized) {

                  initialized = true;
                  g.begin_obsrv = this_time - OBSRV_EPSILON;
                  if (g.begin_obsrv < 0.0) g.begin_obsrv = 0.0;
                }
                else if (this_time < g.begin_obsrv) {

                  g.begin_obsrv = this_time - OBSRV_EPSILON;
                  if (g.begin_obsrv < 0.0) g.begin_obsrv = 0.0;
                }
                if (this_time > g.end_obsrv) g.end_obsrv = this_time;
                g.nodes[column].occurs.push_back(this_time);
              }

              else if (next_char == ';') {
                //cout << "node " << (g.nodes[column].name)
                //     << "has  " << (g.nodes[column].occurs.size()+1)
                //     << "th timestamp = " << (atof(time.c_str())) << endl;
                if (atof(time.c_str()) > 0.0) {
                  double this_time = atof(time.c_str());
                  if (! initialized) {
                    initialized = true;
                    g.begin_obsrv = this_time - 0.1;
                    if (g.begin_obsrv < 0.0) g.begin_obsrv = 0.0;
                  }
                  else if (this_time < g.begin_obsrv) {
                    g.begin_obsrv = this_time - 0.1;
                    if (g.begin_obsrv < 0.0) g.begin_obsrv = 0.0;
                  }
                  if (this_time > g.end_obsrv) g.end_obsrv = this_time;
                  g.nodes[column].occurs.push_back(this_time);
                }
                time.clear();
                time.assign("0");
                column++;
              }

              else 	time.append(1u, next_char);
            }
          }

          row++;
        }
      }
      else cout << "ERROR(read_input) : cannot open this file" << endl;

    } while (!flag);

    g.end_obsrv = g.end_obsrv + OBSRV_EPSILON;
    for (int i = 0; i < g.nodes.size(); i++) {
      g.nodes[i].score = compute_scoreBIC_independantNode(g.nodes[i], g.begin_obsrv, g.end_obsrv);
    }
  }

// =================================================================================
//
void custom_display_graph (tgem_GRAPH graph) {
// =================================================================================

  // std::cout 					  << std::endl;
  std::cout << "Nodes ";

  int i;
  for (i = 0; i < graph.nodes.size()-1; i++) {
    std::cout << graph.nodes[i].name << ", ";
  }
  std::cout << graph.nodes[i++].name << std::endl;

  std::cout << std::endl;
  std::cout << "Edges :" << std::endl;

  for (int j = 0; j < graph.arcs.size(); j++) {
    std::cout << graph.arcs[j].src << "->" << graph.arcs[j].dest << std::endl;

      for (int k = 0; k < graph.arcs[j].tree.size(); k++) {
        std::cout << "(" << graph.arcs[j].tree[k].min << ";" << graph.arcs[j].tree[k].max << "]" << std::endl;
      }
  }
}