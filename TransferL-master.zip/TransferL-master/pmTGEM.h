#ifndef pm_TGEM_H
#define pm_TGEM_H

#include <stdlib.h>
#include <cassert>
#include <iostream>
#include <fstream>
#include <string>
#include <limits.h>
#include <math.h>
#include <map>
#include <list>
#include <vector>
#include <random>
#include <algorithm>
#include <iterator>

#include <boost/graph/copy.hpp>
#include <boost/graph/strong_components.hpp>

#include <pl.h>
#include <plExternalFunctionFromC.h>

#include <pilgrim/general/pmBayesianNetwork.h>

// TGEM EDGES ==================================================================
/**
 *  Can be consider boost graph bundled properties, an easy and efficient way.
 */
//namespace boost {

//struct pmTgemPAST {
//    std::string   name;
//    unsigned      id;
//    pmTgemOCCList(std::string const& n, unsigned i) : name(n),  id(i) {}
//};

// TGEM OCCURENCES =============================================================

typedef  std::pair<double,int>                           pmTgemOCC;
typedef  std::list<pmTgemOCC>                            pmTgemOCCList;
typedef  std::list<int>                                  pmTgemParents;

// TGEM TS =====================================================================
typedef  std::pair<double,double>                        pmTgemTS;
typedef  std::list<pmTgemTS>                             pmTgemTSList;
// --------------------------------------------------------------------- TGEM TS
struct edge_timescales_t {
    typedef boost::edge_property_tag kind;
};
typedef  boost::property<edge_timescales_t,
                         pmTgemTSList,
                         boost::property<boost::edge_name_t, std::string>> pmTgemEdgeProperty;
//}

//namespace PILGRIM {


// ------------------------------------------------------------------ TGEM EDGES

// TGEM VERTICES ===============================================================
/*
struct pmTgemVertexProperty {
    std::string   name;
    unsigned      id;
    pmTgemVertexProperty()                                 : name(""), id(0) {}
    pmTgemVertexProperty(std::string const& n, unsigned i) : name(n),  id(i) {}
};
*/

// --------------------------------------------------------------- TGEM VERTICES

// TGEM GRAPH ==================================================================
typedef boost::adjacency_list<boost::vecS,
                              boost::listS,
                              boost::bidirectionalS,
                              PILGRIM::pmVertexProperty,
                              pmTgemEdgeProperty>       pmTgemGraph;
typedef pmTgemGraph::vertex_descriptor                  pmTgemNode;
typedef pmTgemGraph::vertex_iterator                    pmTgemNodeIterator;
typedef pmTgemGraph::edge_descriptor                    pmTgemEdge;
typedef pmTgemGraph::edge_iterator                      pmTgemEdgeIterator;
typedef pmTgemGraph::out_edge_iterator                  pmTgemEdgeOutIterator;
typedef pmTgemGraph::in_edge_iterator                   pmTgemEdgeInIterator;
// ------------------------------------------------------------------ TGEM GRAPH

typedef  std::tuple<int, int, int, int>                 pmTgemNeighbour;
typedef  std::list<pmTgemTS>                             pmTgemTSList;

#define TGEM_OPERATOR_NONE      0
#define TGEM_OPERATOR_ADD       1
#define TGEM_OPERATOR_EXTEND    2
#define TGEM_OPERATOR_SPLIT     3
#define TGEM_OPERATOR_REMOVE    4
#define TGEM_OPERATOR_MERGE     5
#define TGEM_OPERATOR_REDUCE    6
#define TGEM_OPERATOR_FORWARD   7
#define TGEM_OPERATOR_DISTANCE  8

class pmTgem {

public:
  /*!
   *  \brief Default constructor.
   */
                  pmTgem();

  /**
   * \brief Main constructor
   */
                  pmTgem        (std::vector<std::string>           _events);
  virtual         ~pmTgem       ();

  std::map<std::string, pmTgemNode>     event_2_node;
  std::map<int,  std::string>           id_2_event;

  pmTgemGraph                           graph;
  pmTgemOCCList*                        past;
  pmTgemParents*                        parents;
  int*                                  nb_TSparents;
  pmTgemNeighbour*                      neighbours;
  int                                   neighbour_mode = 0;

  void            display_graph (std::vector<std::string>          _events);
  int             add_edge      (std::string                       _src,
                                 std::string                       _dest,
                                 double                            _horizon);
  int             extend_edge   (pmTgemEdge                        _edge);
  int             split_edge    (pmTgemEdge                        _edge,
                                 int                               _row);
  int             remove_edge   (pmTgemEdge                        _edge);
  int             merge_edge    (pmTgemEdge                        _edge);
  int             reduce_edge   (pmTgemEdge                        _edge);
  int             apply_operator_edge(pmTgemEdge                   _edge,
                                 int                               _operator);
  int             apply_operator_edge(pmTgemEdge                   _edge,
                                 int                               _operator,
                                 int                               _row);
  int             apply_operator(std::string                       _src,
                                 std::string                       _dest,
                                 int                               _operator);
  int             apply_operator(std::string                       _src,
                                 std::string                       _dest,
                                 int                               _operator,
                                 int                               _row);
  int             distance_diff (pmTgemGraph                       _othergraph);
  double          distance_same (pmTgemGraph                       _othergraph);
  int             forward       ();
  void            display_neighbours();
//private:

    int             node_2_id     (pmTgemNode                       _node);

    pmTgemEdge      get_edge      (pmTgemNode                       _src,
                                   pmTgemNode                       _dest,
                                   bool*                            _existing);
    pmTgemTSList    get_TSlist    (pmTgemEdge                       _edge);
    void            set_TSlist    (pmTgemEdge                       _edge,
                                   pmTgemTSList&                    _tslist);
    double          get_horizon   (pmTgemEdge                       _edge);

    void            display_past  (std::string                      _event);
    void            fill_past     (std::string                      _event,
                                   std::list<double>&               _occ);
    int             scan_past     (int                              _idnode,
                                   double                           _begin,
                                   double                           _end);
    int             scan_past     (pmTgemNode                       _node,
                                   double                           _begin,
                                   double                           _end);
    int             scan_past     (std::string                      _event,
                                   double                           _begin,
                                   double                           _end);
    int             scan_past     (pmTgemEdge                       _edge,
                                   double                           _begin,
                                   double                           _end);
    void            display_parents (std::string                    _event);
    int             getNbParents  (pmTgemNode                       _node);
    int             getNbParents  (std::string                      _event);
    int             getNbParents  (pmTgemEdge                       _edge);

    int             generate_sampling();

  //protected:

    //boost::property_map<pmGraph, boost::edge_timescales_t>::type edge_TSlist;
};
//};          // namespace PILGRIM
#endif      // pm_TGEM_H
