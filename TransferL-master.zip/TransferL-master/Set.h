
#include <vector>

#include "test_TGEM.h"

class Set {
    public:
        Set() {}
        Set(int nb_tasks, double delta) {
            this->nb_tasks = nb_tasks;
            this->z = 2;
            this->delta = delta;
            this->horizon = 5;

            std::vector<double> prior_indiv(nb_tasks, 0.5);
            this->individuals_priors = prior_indiv;

            this->set_prior(this->compute_prior());
            this->set_score(this->compute_score());

            generate_id2labels(); // creates map id2labels

            this->logs.open(this->title, std::ios::out);
        }
        
        Set(std::vector<tgem_GRAPH> models, double delta, std::vector<std::map<std::string, int>> labels2id) {
            this->nb_tasks = models.size();
            this->models = models;
            this->z = 2;
            this->delta = delta;
            this->horizon = 5;
            this->labels2id = labels2id;

            std::vector<double> prior_indiv(nb_tasks, 0.5);
            this->individuals_priors = prior_indiv;
            
            this->set_prior(this->compute_prior());
            this->set_score(this->compute_score());

            generate_id2labels();

            this->logs.open(this->title, std::ios::out);
            this->logs_csv.open(this->title_csv, std::ios::out);
            this->logs_csv << "idIteration;idBnb;operation;source;dest;nbParcouru;nbPossible;configuration;score\n";

            this->idBnB = 0;
            this->idIteration = 0;
        }

        typedef std::pair<std::pair<int, std::vector<int> >, std::pair<std::pair<std::string,std::string>, pmTgemTS> > operation;

        std::pair<std::pair<operation,std::string>, double> branch_and_bound(std::map<std::string, int> &map_scores,
                                            operation op, std::string &best_configuration, std::vector<float> bests);

        double compute_score(operation op, std::string configuration, int level, 
                                            std::vector<float> bests, bool test);
        double compute_score();
        double compute_prior();
        void compute_nb_tasks() { this->nb_tasks = this->individuals_priors.size(); }
        void generate_id2labels();
        void log_operation(int potential_operator, std::pair<std::pair<std::string,std::string>, pmTgemTS> arguments);
        double apply_operation(operation op, std::string configuration);

        /* setters */
        void set_z(double constant) { this->z = constant; }
        void set_score(double score) { this->score = score; }
        void set_delta(double delta) { this->delta = delta; }
        void set_prior(double prior) { this->prior = prior; }
        void set_individuals_priors(std::vector<double> priors) { this->individuals_priors = priors; }
        
        /* getters */
        int get_nb_tasks() { return this->nb_tasks; }
        double get_z() { return this->z; }
        double get_score() { return this->score; }
        double get_prior() { return this->prior; }
        double get_delta() { return this->delta; }
        double get_horizon() { return this->horizon; }
        char get_default_value() { return this->default_value; }
        std::vector<std::map<int, std::string>> get_id2labels() { return this->id2labels; }
        std::vector<std::map<std::string, int>> get_labels2id() { return this->labels2id; }
        std::vector<double> get_individuals_priors() { return this->individuals_priors; }

        std::vector<tgem_GRAPH> models;
        std::ofstream logs;
        std::ofstream logs_csv;
        int idIteration;

    private:
        char default_value = '2';
        int nb_tasks; // k, voir si c'est pas mieux de le déduire
        double z; // normalization constant
        double score;
        double prior;
        double delta;
        std::vector<double> individuals_priors;
        std::vector<std::map<std::string, int>> labels2id;
        std::vector<std::map<int, std::string>> id2labels;
        int horizon;
        int idBnB; // current number of branch and bound
        
        std::string title = "./output/branch-and-bound.log";
        std::string title_csv = "./output/branch-and-bound.csv";
};

int timescale_id(tgem_EDGE e, pmTgemTS ts);
std::string name_operator(int op);

