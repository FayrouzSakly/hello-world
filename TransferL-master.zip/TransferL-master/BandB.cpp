#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/depth_first_search.hpp>
#include <iostream>
#include <fstream> 
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "BandB.h"
// #include "pmTGEM.h"
// #include "test_TGEM.h"
// #include "Set.h"

using namespace PILGRIM;
using namespace boost;

int main()
{   
    // std::string folder_to_data = "./input/data";
    std::string path_to_data1 = "./input/data1.csv";
    std::string path_to_data2 = "./input/data2.csv";
    std::string path_to_data3 = "./input/data3.csv";
    std::string path_to_data4 = "./input/data4.csv";

    std::ofstream general_logs;
    std::string name = "./output/transfer-learning.csv";
    general_logs.open(name, std::ios::out); // open file
    general_logs << "idIteration;BestScore;operation;source;dest;models;BestConfiguration;Forward;Time\n";

    /* general parameters */
    int nb_tasks = 3; // voir quel est le problème avec 4 ?? (affiche pas "Apply op on model " etc)
    char default_value = '2';
    double delta = 0.2;
    double time;
    clock_t start;


    /* creates set */
    std::vector<std::map<std::string, int>> labels2id;
    std::map<std::string, int> label2id;
    for (int i = 0; i < nb_tasks; i++){
        labels2id.push_back(label2id);
    }

    tgem_GRAPH g;
    std::vector<tgem_GRAPH> models; // à changer pour que + générique = puisse contenir BN
    
    std::vector<std::string> paths_to_data;
    paths_to_data.push_back(path_to_data1);
    paths_to_data.push_back(path_to_data2);
    paths_to_data.push_back(path_to_data3);

    for (int model = 0; model < nb_tasks; model++){
        // std::string path_to_data = "./input/" +  + "data.csv";
        models.push_back(g);
    }

    build_graphs(models, paths_to_data, labels2id); // computes scores etc
    Set s(models, delta, labels2id);


    /* extract labels of events from labels2id map */
    std::vector< std::string > events;

    std::map<std::string, int>::iterator it;
    for (int model = 0; model < s.get_nb_tasks(); model++){
        for (int node = 0; node < s.models[model].nodes.size(); node++){
            std::string new_label = s.models[model].nodes[node].name;
            // std::cout << new_label << "?" << std::endl;
            auto result = std::find(events.begin(), events.end(), new_label);
            if (result == events.end()) { // if label isn't already in events
                events.push_back(new_label);
            }
        }
    }

    // display_nodes_name(events, s);

    std::cout << "SCOOOOOOOOORE " << s.get_score() << std::endl;
    std::cout << "Prior : " << s.get_prior() << std::endl;

    double epsilon = 2; // quel est un epsilon raisonnable ? 10e-4 à 10e-6
    bool convergence = false;
    int compte = 6; // temp
    std::vector<float> bests;

    double current_score, final_score;
    std::pair<std::pair<operation,std::string>, double> best_score, new_score;
    std::string best_configuration(nb_tasks, s.get_default_value());

    int choosen_op;
    
    std::map<std::string, int> map_scores; // temp
    if (nb_tasks == 3) {
        map_scores["000"] = 0;
        map_scores["001"] = 0;
        map_scores["010"] = 0;
        map_scores["011"] = 0;
        map_scores["100"] = 2;
        map_scores["101"] = 0;
        map_scores["110"] = 10;
        map_scores["111"] = 0;
        map_scores["002"] = 0;
        map_scores["012"] = 0;
        map_scores["102"] = 2;
        map_scores["112"] = 10; 
        map_scores["022"] = 3; // elagage
        map_scores["122"] = 5;
        map_scores["222"] = 4;

    } else if (nb_tasks == 4) {
        map_scores["2222"] = 5;

        map_scores["0222"] = 6; 
        map_scores["1222"] = 9;

        map_scores["0022"] = 0; // elagage
        map_scores["0122"] = 7;
        map_scores["1022"] = 10;
        map_scores["1122"] = 13; 

        map_scores["0002"] = 0; // non exploré
        map_scores["0012"] = 0; // non exploré
        map_scores["0102"] = 8;
        map_scores["0112"] = 0; // elagage
        map_scores["1002"] = 11;
        map_scores["1012"] = 0; // elagage
        map_scores["1102"] = 14;
        map_scores["1112"] = 0; // elagage

        map_scores["0000"] = 0; // non exploré
        map_scores["0001"] = 0; // non exploré
        map_scores["0010"] = 0; // non exploré
        map_scores["0011"] = 0; // non exploré
        map_scores["0100"] = 0;
        map_scores["0101"] = 0;
        map_scores["0110"] = 0; // non exploré
        map_scores["0111"] = 0; // non exploré
        
        map_scores["1000"] = 0;
        map_scores["1001"] = 12;
        map_scores["1010"] = 0; // non exploré
        map_scores["1011"] = 0; // non exploré
        map_scores["1100"] = 0;
        map_scores["1101"] = 0;
        map_scores["1110"] = 0; // non exploré
        map_scores["1111"] = 0; // non exploré
    }

    bool forward = true;
    best_score.second = 0;

    /* Forward search beginning */
    while(compte != 0){ // temp : changer condition en fonction de convergence
        start = clock();
        compte--;

        // if (compte == 0){ // temp : changer condition en fonction de convergence
        //     forward = false;
        // }

        if (forward) {
            std::cout << "-------- FORWARD SEARCH --------" << std::endl;
        } else {
            std::cout << "-------- BACKWARD SEARCH --------" << std::endl;
        }

        std::cout << "  Iteration " << s.idIteration << std::endl;

        /* organize future operations */
        edgeConfiguration configuration = build_edge_configuration(events, s.models, s.get_id2labels());
        display_edge_configuration(configuration);
        std::vector<operation> list_operations = create_list_operations(configuration, forward);
        display_list_operations(list_operations);

        // // ajoute arc dans modèle 0 et 2
        // int src_node = label2id[s.models[0].nodes[0].name];
        // int dst_node = label2id[s.models[0].nodes[1].name];
        // add_TS(s.models[0], src_node, dst_node, s.get_horizon(), CHOOSE_NEIGHBOUR);

        // src_node = label2id[s.models[2].nodes[2].name];
        // dst_node = label2id[s.models[2].nodes[3].name];
        // add_TS(s.models[2], src_node, dst_node, s.get_horizon(), CHOOSE_NEIGHBOUR);

        // std::cout << " APRES AJOUT DE L'ARC " << std::endl;

        // configuration = build_edge_configuration(events, s.models, s.get_id2labels());
        // display_edge_configuration(configuration);
        // list_operations = create_list_operations(configuration, forward);
        // display_list_operations(list_operations);

        for (int i = 0; i < list_operations.size(); i++) {
            // operation next_operation = list_operations.back();
            // list_operations.pop_back();
            operation next_operation = list_operations[i];
            // list_operations.pop_back();

            std::cout << "Next operation: ";
            display_operation(next_operation);

            // std::vector<tgem_GRAPH> models_to_compute;
            // for (int model = 0; model < next_operation.first.second.size(); model++){
            //     int id_model_to_compute = next_operation.first.second[model];
            //     models_to_compute.push_back(s.models[id_model_to_compute]);
            // }

            /* calcul du meilleur score voisin pour chaque modèle */
            bests = find_best_neighbour(s.models, next_operation, 
                                                        s.get_labels2id(), s.get_id2labels());
            // std::cout << "Scores: ";
            // for (int i = 0; i < bests.size(); i++){
            //     std::cout << bests[i] << " ";
            // }
            // std::cout << std::endl;

            /* branch and bound */
            new_score = s.branch_and_bound(map_scores, next_operation, best_configuration, bests);

            if (new_score.second > best_score.second) {
                std::cout << "Update score" << std::endl;
                best_score = new_score;
            }
            std::cout << std::endl;
        }

        choosen_op = best_score.first.first.first.first;
        final_score = best_score.second;

        std::cout << "Final score = " << final_score << ", operation to apply " << name_operator(choosen_op) << std::endl;
        std::cout << std::endl;

        // apply final decision
        operation operation_to_apply = best_score.first.first;
        std::cout << "Iteration " << s.idIteration << ": " << s.apply_operation(operation_to_apply, best_configuration) << std::endl;

        if ((current_score-best_score.second)<epsilon){
            convergence = true;
        }

        std::cout << "BRAAAAAAAAAAAAAAAAAAAAAAH"<< std::endl;
        time = (double)(clock()-start)/(double)CLOCKS_PER_SEC;
        general_logs << s.idIteration << ";" << final_score << ";" << name_operator(operation_to_apply.first.first) 
                        << ";" << operation_to_apply.second.first.first << ";" << operation_to_apply.second.first.second << ";";

        for (int model = 0; model < operation_to_apply.first.second.size(); model++){
            general_logs << operation_to_apply.first.second[model];
            std::cout << operation_to_apply.first.second[model];
        }

        general_logs << ";" << best_configuration << ";" << forward << ";" << time << std::endl;

        s.idIteration++;

        for (int model = 0; model < s.get_nb_tasks(); model++){
            std::cout << std::endl;
            std::cout << "================================" << std::endl;
            std::cout << "Model " << model << std::endl;
            custom_display_graph(s.models[model]);
        }
    }

    general_logs.close(); // close file to free memory
    s.logs.close();
    s.logs_csv.close();

    return 0;
}

std::vector<operation> create_list_operations(edgeConfiguration map, bool forward){

    std::vector<operation> list_operations;
    
    for (edgeConfiguration::const_iterator iter = map.begin(); iter != map.end(); iter++){
        std::pair<std::pair<std::string,std::string>, pmTgemTS> edge = (iter->first);
        pmTgemTS timescale = (iter->first).second;
        std::vector<int> models = iter->second;

        std::pair<int, std::vector<int> > operations_models; // looks like default is OPERATOR_ADD
        operations_models.second = models;

        if (forward) {
            if((timescale.first == 0) and (timescale.second == 0)){ // if no timescale, edge doesn't exist
                operations_models.first = OPERATOR_ADD;
            } else { // if edge exists : split timescale
                operations_models.first = OPERATOR_SPLIT;
            }

            operation new_operation(operations_models,edge);
            list_operations.push_back(new_operation);
            
            // extend : only once for each edge,
            // when the first element is 0
            if((timescale.first == 0) and (timescale.second != 0)){
                operations_models.first = OPERATOR_EXTEND;
                new_operation = std::make_pair(operations_models,edge);
                list_operations.push_back(new_operation);
            }

        } else { // backward search

            int nb_ts = 1; // temp

            if(timescale.second != 0){ // if edge exists
                if (nb_ts == 1) { // if edge exists and only one timescale: delete edge
                    operations_models.first = OPERATOR_REMOVE;
                } else { // nb_ts > 1
                    operations_models.first = OPERATOR_MERGE;
                }

                operation new_operation(operations_models,edge);
                list_operations.push_back(new_operation);

                if(timescale.first == 0){ // if edge is the "last" one
                    operations_models.first = OPERATOR_REDUCE;
                    new_operation = std::make_pair(operations_models,edge);
                    list_operations.push_back(new_operation);
                }
            }

            // if((timescale.first == 0) and (timescale.second == 0)){ // if no timescale, edge doesn't exist
                // operations_models.first = OPERATOR_SPLIT;
                // std::cout << "blop" << std::endl;
            // } 
            // if (nb_ts == 1) { // if edge exists and only one timescale: delete edge
            //     operations_models.first = OPERATOR_REMOVE;
            // } else { // nb_ts > 1
            //     operations_models.first = OPERATOR_MERGE;
            // }

            // operation new_operation(operations_models,edge);
            // list_operations.push_back(new_operation);
            
            // reduce : only once for each edge,
            // when the first element is 0
            // if(timescale.first == 0){
            // if((timescale.first == 0) and (timescale.second != 0)){ // if edge exists and is the "last" one
            //     operations_models.first = OPERATOR_REDUCE;
            //     new_operation = std::make_pair(operations_models,edge);
            //     list_operations.push_back(new_operation);
            // }
        }

    }

    return list_operations;
}

edgeConfiguration build_edge_configuration(std::vector<std::string> events, 
                                            std::vector<tgem_GRAPH> graphs,
                                            std::vector<std::map<int, std::string>> id2labels) {
    
    edgeConfiguration configuration;

    pmTgemTS empty_ts(0,0), ts1(0,5);

    std::pair<std::string,std::string> nodes;
    std::pair <std::pair<std::string,std::string>, pmTgemTS> edge;
    std::vector<int> models_existing, models_non_existing;
    
    std::vector<std::map<std::string,std::map<std::string,int>>> existing_edges;
    std::map<std::string,std::map<std::string,int>> existing_edge;
    int E;
    int N;
    std::vector<tgem_NODE> nodes_graphs;

    // initialize existing_edges
    for (int model = 0; model < graphs.size(); model++){
        nodes_graphs = graphs[model].nodes; // model nodes
        existing_edges.push_back(existing_edge);
        N = nodes_graphs.size();
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++){
                existing_edges[model][nodes_graphs[i].name][nodes_graphs[j].name] = -1;
            }
        }
    }

    for (int model = 0; model < graphs.size(); model++){
        E = graphs[model].arcs.size();

        for (int e = 0+1; e < E+1; e++) { // ajouté +1 car pb d'intersection events/nodes, il faut changer la boucle d'en dessous car les indices n'existant pas renvoient un 0 dans existing_edges
            int src = graphs[model].arcs[e-1].src;
            int dest = graphs[model].arcs[e-1].dest;

            std::string src_label = id2labels[model][src];
            std::string dest_label = id2labels[model][dest];

            // std::cout << "exists edge between " << src_label << " and " << dest_label << ", id = " << e;
            existing_edges[model][src_label][dest_label] = e;
        }
    }
 
    for (int source = 0; source < events.size(); source++){ // all combinations for every node
        for (int target = 0; target < events.size(); target++){

            nodes = std::make_pair(events[source], events[target]);

            models_existing.clear();
            models_non_existing.clear();

            for (int model = 0; model < graphs.size(); model++){
                if (existing_edges[model][events[source]][events[target]] > 0){ // if edge exists
                    // g.get_edge(source, target, existing); // checks if edge exists
                    models_existing.push_back(model);
                } else if (existing_edges[model][events[source]][events[target]] == -1) { // if it doesn't
                    models_non_existing.push_back(model);
                }
            }

            // std::cout << events[source] << "->" << events[target] << ", existing : " << models_existing.size() << ", non existing " << models_non_existing.size() << std::endl;
            if (models_existing.size() > 0) { // if some model has this existing edge
                edge = std::make_pair(nodes, ts1);
                configuration[edge] = models_existing;
            }

            if (models_non_existing.size() > 0) { // if some model has this non existing edge
                edge = std::make_pair(nodes, empty_ts);
                configuration[edge] = models_non_existing;
            }
        }
    }
    return configuration;
}

edgeConfiguration create_edge_configuration(std::vector<std::string> events) {
    
    edgeConfiguration configuration;

    pmTgemTS empty_ts(0,0);
    pmTgemTS ts1(0,5);
    pmTgemTS ts2(5,10);

    bool existing;
    int number_ts;

    std::pair<std::string,std::string> nodes;
    std::pair <std::pair<std::string,std::string>, pmTgemTS> edge;
    std::vector<int> models;
    pmTgemTS ts;

    for (int source = 0; source < events.size() ; source++){ // all combinations for every node
        for (int target = 0; target < events.size() ; target++){

            existing = std::rand()%2; // choses randomly if next edge exists or not
            nodes = std::make_pair(events[source], events[target]);

            models.clear();

            if (existing) {
                ts = ts1;
                models.push_back(0); // indices of the models
                models.push_back(1); // pourquoi marche pas si seulement deux models dans le vector
                models.push_back(2);

            } else {
                ts = empty_ts;
                models.push_back(1); // indices of the models
                models.push_back(4);
            }

            edge = std::make_pair(nodes, ts);
            configuration[edge] = models;

            number_ts = std::rand()%2+1; // choses randomly if next edge has two ts or one
            if (existing && number_ts == 2){
                ts = ts2;
                models.push_back(3);
            }

            edge = std::make_pair(nodes, ts);
            configuration[edge] = models;

        }
    }

    return configuration;
}

void display_list_operations(std::vector<operation> list_operations) {
    std::cout << "Nombre d op " << list_operations.size() << std::endl;
    for (int i = 0; i < list_operations.size(); i++){
        display_operation(list_operations[i]);
    }
}

// faire que cette fonction renvoie le même type que std::cout 
// void apply_operation(operation oper){
//     int op;
//     std::vector<int> models_op;
//     std::pair<std::pair<std::string,std::string>, pmTgemTS> arguments;
//     std::string name_op;

//     op = oper.first.first;
//     models_op = oper.first.second;
//     arguments = oper.second;
//     name_op = name_operator(op);

//     std::cout << name_op;

//     int src_node, dst_node;
    
//     for (j = 0; j < models_op.size(); j++) {
//         src_node = arguments.first.first;
//         dst_node = arguments.first.second;
//         std::cout << "(" << src_node << "->" << dst_node;

//         if (op == OPERATOR_ADD){ // add
//             add_TS(this->models[j], src_node, dst_node, s.get_horizon(), CHOOSE_NEIGHBOUR);
//             std::cout << "";
//         } else if (op == OPERATOR_EXTEND){ // extend
//             std::cout << ", (" << arguments.second.first << "," << arguments.second.second << "]";
//         } else if (op == OPERATOR_SPLIT){ // split
//             std::cout << " h = ?";
//             /* h = *fonction qui get l'horizon* */
//         } else if (op == OPERATOR_REMOVE){ // remove
//             std::cout << "";
//         } else if (op == OPERATOR_MERGE){ // merge
//             std::cout << ", (" << arguments.second.first << "," << arguments.second.second << "] and ...";
//         } else if (op == OPERATOR_REDUCE){ // reduce
//             std::cout << " h = ?";
//             /* h = *fonction qui get l'horizon* */
//         }
//         std::cout << ")";
//     }
//     std::cout << std::endl;
// }

// TODO faire que cette fonction renvoie le même type que std::cout 
void display_operation(operation oper){
    int op;
    std::vector<int> models_op;

    std::string name_op;

    op = oper.first.first;
    models_op = oper.first.second;
    std::pair<std::pair<std::string,std::string>, pmTgemTS> arguments = oper.second;

    name_op = name_operator(op);

    std::cout << name_op;
    
    std::cout << "(" << arguments.first.first << "->" << arguments.first.second;
    if (op == OPERATOR_ADD){ // add
        std::cout << "";
    } else if (op == OPERATOR_EXTEND){ // extend
        std::cout << ", (" << arguments.second.first << "," << arguments.second.second << "]";
    } else if (op == OPERATOR_SPLIT){ // split
        std::cout << " h = ?";
        /* h = *fonction qui get l'horizon* */
    } else if (op == OPERATOR_REMOVE){ // remove
        std::cout << "";
    } else if (op == OPERATOR_MERGE){ // merge
        std::cout << ", (" << arguments.second.first << "," << arguments.second.second << "] and ...";
    } else if (op == OPERATOR_REDUCE){ // reduce
        std::cout << " h = ?";
        /* h = *fonction qui get l'horizon* */
    }
    std::cout << ")";

    // std::cout << " on models ";
    // int j;
    // for (j = 0; j < (models_op.size()-1); j++) {
    //     std::cout << models_op[j] << ",";
    // }
    // std::cout << models_op[j++] << std::endl;
    std::cout << std::endl;

}

void display_edge_configuration(edgeConfiguration map){

    std::cout << std::endl << "  Edge configuration  " << std::endl;
    
    for (edgeConfiguration::const_iterator iter = map.begin(); iter != map.end(); iter++){
        std::pair<std::string,std::string> edge = (iter->first).first;
        pmTgemTS timescale = (iter->first).second;
        std::vector<int> models = iter->second;

        // edge
        std::cout << edge.first << "->" << edge.second << " - ";

        // timescales
        if((timescale.first == 0) and (timescale.second == 0)){
            std::cout << "x : ";
        } else {
            std::cout << "(" << timescale.first << "," << timescale.second << "] : ";
        }

        // models
        for (int model = 0; model < models.size(); model++){
            std::cout << models[model];
        }

        std::cout << std::endl;
    }
}


void display_nodes_name(std::vector<std::string> events, Set s) {

    std::cout << " -------- 1 --------" << std::endl << std::endl;

    std::cout << "nombre events " << events.size() << ", noms :" << std::endl;
    for (int i = 0; i < events.size(); i++){
        std::cout << events[i];
        // std::cout << "   " << events[i].size() << std::endl;
    }
    std::cout << std::endl;

    std::cout << " -------- 2 --------" << std::endl << std::endl;

    for (int model = 0; model < s.get_nb_tasks(); model++){
        std::cout << "model " << model << ", nombre events " << s.models[model].nodes.size() << ", noms :" << std::endl;
        for (int node = 0; node < s.models[model].nodes.size(); node++){
            std::cout << s.models[model].nodes[node].name << std::endl;
            std::cout << "   " << s.models[model].nodes[node].name.size() << std::endl;
        }
    }

    std::cout << " -------- 3 --------" << std::endl << std::endl;

    std::vector<std::map<std::string,int>> labels2id = s.get_labels2id();
    std::map<std::string, int>::iterator it;
    for (int model = 0; model < s.get_nb_tasks(); model++){
        std::cout << "model " << model << ", nombre events " << labels2id[model].size() << ", noms :" << std::endl;
        for (it = labels2id[model].begin(); it != labels2id[model].end(); it++){
            std::cout << it->first << " (" << it->second << ")" << std::endl;
        }
    }
}


std::vector<float> find_best_neighbour(std::vector<tgem_GRAPH> &graphs, Set::operation oper,
                                    std::vector<std::map<std::string, int>> labels2id,
                                    std::vector<std::map<int, std::string>> id2labels){
    
    std::vector<float> best_scores; // no need to store indices, only scores
    double graph_score, best_score;
    // bool   best_done = false;
    double hrz = 5; // horizon
    
    int src, dest, arg1, arg2;
    std::string src_label, dest_label;
    int E, N;
    int edgeID;

    std::vector<std::map<std::string,std::map<std::string,int>>> existing_edges = initialize_existing_edges(graphs, id2labels);

    int op = oper.first.first;
    std::vector<int> models_op = oper.first.second;
    std::pair<std::pair<std::string,std::string>, pmTgemTS> arguments = oper.second;
    pmTgemTS ts = arguments.second;

    int model = models_op[0];

    src_label = arguments.first.first;
    dest_label = arguments.first.second;

    src = labels2id[model][src_label];
    dest = labels2id[model][dest_label];

    if ((op == OPERATOR_EXTEND) || (op == OPERATOR_SPLIT)){
        edgeID = existing_edges[model][src_label][dest_label];
    }

    if (op == OPERATOR_ADD){ // add
        arg1 = src;
        arg2 = dest;
    } else if (op == OPERATOR_EXTEND){ // extend
        arg1 = edgeID;
    } else if (op == OPERATOR_SPLIT){ // split
        arg1 = edgeID;
        arg2 = timescale_id(graphs[model].arcs[edgeID], ts);
    // } else if (op == OPERATOR_REMOVE){ // remove
    //     std::cout << "";
    // } else if (op == OPERATOR_MERGE){ // merge
    //     std::cout << ", (" << arguments.second.first << "," << arguments.second.second << "] and ...";
    // } else if (op == OPERATOR_REDUCE){ // reduce
    //     std::cout << " h = ?";
    //     /* h = *fonction qui get l'horizon* */
    }

  for (int model = 0; model < graphs.size(); model++){
    // compute current scores
    graph_score = 0.0;
    for (int i = 0; i < graphs[model].nodes.size(); i++) {
        graph_score += graphs[model].nodes[i].score;
    }

    // int potential_operator = op.first.first;
    // changer ici pour qu'on applique que l'operation proposée
    double score = graph_score;
    double delta_score;

    auto result = std::find(oper.first.second.begin(), 
                    oper.first.second.end(), model); // if operation has to be applied on current model

    if (result != oper.first.second.end()) { // if in vector
        if (op == OPERATOR_ADD){
            delta_score = add_TS(graphs[model], arg1, arg2, hrz, TEST_NEIGHBOUR);
        }         
        else if (op == OPERATOR_EXTEND) {

            std::cout << "blopblop" << std::endl;
            delta_score = extend_TS(graphs[model], arg1, TEST_NEIGHBOUR);

            std::cout << "blop6" << std::endl;
        } 
        else if (op == OPERATOR_SPLIT) {
            delta_score = split_TS(graphs[model], arg1, arg2, TEST_NEIGHBOUR);
        } 
        else if (op == OPERATOR_REMOVE) {
            delta_score = 25;
            // score = split_TS(graphs[model], arg1, arg2, TEST_NEIGHBOUR);
        } 
        else if (op == OPERATOR_MERGE) {
            delta_score = -25;
            // score = split_TS(graphs[model], arg1, arg2, TEST_NEIGHBOUR);
        } 
        else if (op == OPERATOR_REDUCE) {
            delta_score = 10;
            // score = split_TS(graphs[model], arg1, arg2, TEST_NEIGHBOUR);
        }
    } else delta_score = 0;

    if (delta_score > 0){ // si l'opération augmente le score, on l'additionne au meilleur score 
        score += delta_score;
    }
    // best_score = score;

    // if (!best_done) {
    //     best_done = true;
    //     best_score = score;
    // } else if (score > best_score) {
    //     best_score = score;
    // }
    best_scores.push_back(score);   
  }
  return best_scores;
}

std::vector<std::map<std::string,std::map<std::string,int>>> initialize_existing_edges(std::vector<tgem_GRAPH> graphs,
                                    std::vector<std::map<int, std::string>> id2labels){

    std::vector<std::map<std::string,std::map<std::string,int>>> existing_edges;
    std::map<std::string,std::map<std::string,int>> existing_edge;
    std::vector<tgem_NODE> nodes_graphs;

    int model;
    int src, dest;
    std::string src_label, dest_label;
    int E, N;

    for (model = 0; model < graphs.size(); model++){
        nodes_graphs = graphs[model].nodes; // model nodes
        existing_edges.push_back(existing_edge);
        N = nodes_graphs.size();
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++){
                existing_edges[model][nodes_graphs[i].name][nodes_graphs[j].name] = -1;
            }
        }
    }

    for (model = 0; model < graphs.size(); model++){
        E = graphs[model].arcs.size();

        for (int e = 0; e < E; e++) {
            src = graphs[model].arcs[e].src;
            dest = graphs[model].arcs[e].dest;

            src_label = id2labels[model][src];
            dest_label = id2labels[model][dest];

            // std::cout << "exists edge between " << src_label << " and " << dest_label << ", id = " << e << std::endl;
            existing_edges[model][src_label][dest_label] = e;
        }
    }
    return existing_edges;
}

